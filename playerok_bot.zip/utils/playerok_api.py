#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import json
import logging
import aiohttp
import asyncio
import time
from bs4 import BeautifulSoup

# Настройка логирования
logger = logging.getLogger(__name__)

class PlayerokAPI:
    """Класс для работы с API Playerok"""
    
    def __init__(self):
        """Инициализация API"""
        self.base_url = "https://playerok.com"
        self.login_url = f"{self.base_url}/login"
        self.profile_url = f"{self.base_url}/profile"
        self.items_url = f"{self.base_url}/items"
        self.orders_url = f"{self.base_url}/orders"
        self.sessions = {}  # Сессии для разных аккаунтов
        
    async def login(self, username, password):
        """Авторизация на Playerok"""
        try:
            # Создаем новую сессию для аккаунта
            session = aiohttp.ClientSession()
            
            # Получаем CSRF-токен
            async with session.get(self.login_url) as response:
                if response.status != 200:
                    await session.close()
                    return False, f"Ошибка при получении страницы входа: {response.status}"
                
                html = await response.text()
                soup = BeautifulSoup(html, 'html.parser')
                csrf_token = soup.find('meta', {'name': 'csrf-token'})
                
                if not csrf_token:
                    await session.close()
                    return False, "Не удалось получить CSRF-токен"
                
                csrf_token = csrf_token.get('content', '')
            
            # Выполняем вход
            headers = {
                'X-CSRF-TOKEN': csrf_token,
                'X-Requested-With': 'XMLHttpRequest',
                'Referer': self.login_url
            }
            
            data = {
                'login': username,
                'password': password,
                '_token': csrf_token
            }
            
            async with session.post(self.login_url, headers=headers, data=data) as response:
                if response.status != 200:
                    await session.close()
                    return False, f"Ошибка при входе: {response.status}"
                
                response_data = await response.json()
                
                if not response_data.get('success', False):
                    await session.close()
                    return False, response_data.get('message', 'Неизвестная ошибка при входе')
            
            # Проверяем, что вход выполнен успешно
            async with session.get(self.profile_url) as response:
                if response.status != 200:
                    await session.close()
                    return False, f"Ошибка при проверке входа: {response.status}"
                
                html = await response.text()
                if username.lower() not in html.lower():
                    await session.close()
                    return False, "Не удалось подтвердить вход"
            
            # Сохраняем сессию
            self.sessions[username] = session
            
            return True, "Вход выполнен успешно"
            
        except Exception as e:
            logger.error(f"Ошибка при входе: {e}")
            if username in self.sessions:
                await self.sessions[username].close()
                del self.sessions[username]
            return False, f"Исключение при входе: {str(e)}"
    
    async def bump_items(self, username, password):
        """Поднятие товаров"""
        try:
            # Проверяем, есть ли активная сессия
            if username not in self.sessions:
                success, message = await self.login(username, password)
                if not success:
                    return False, f"Ошибка при входе: {message}"
            
            session = self.sessions[username]
            
            # Получаем список товаров
            async with session.get(self.items_url) as response:
                if response.status != 200:
                    return False, f"Ошибка при получении списка товаров: {response.status}"
                
                html = await response.text()
                soup = BeautifulSoup(html, 'html.parser')
                
                # Находим все товары
                items = soup.find_all('div', class_='item')
                
                if not items:
                    return True, "Нет товаров для поднятия"
                
                # Получаем CSRF-токен
                csrf_token = soup.find('meta', {'name': 'csrf-token'})
                if not csrf_token:
                    return False, "Не удалось получить CSRF-токен"
                csrf_token = csrf_token.get('content', '')
                
                # Поднимаем каждый товар
                bumped_count = 0
                for item in items:
                    # Находим ID товара
                    item_id = item.get('data-id')
                    if not item_id:
                        continue
                    
                    # Проверяем, можно ли поднять товар
                    bump_button = item.find('button', {'data-action': 'bump'})
                    if not bump_button or 'disabled' in bump_button.attrs:
                        continue
                    
                    # Поднимаем товар
                    bump_url = f"{self.base_url}/items/{item_id}/bump"
                    headers = {
                        'X-CSRF-TOKEN': csrf_token,
                        'X-Requested-With': 'XMLHttpRequest',
                        'Referer': self.items_url
                    }
                    
                    async with session.post(bump_url, headers=headers) as bump_response:
                        if bump_response.status != 200:
                            continue
                        
                        bump_data = await bump_response.json()
                        if bump_data.get('success', False):
                            bumped_count += 1
                    
                    # Делаем паузу между запросами
                    await asyncio.sleep(1)
                
                return True, f"Поднято товаров: {bumped_count}"
                
        except Exception as e:
            logger.error(f"Ошибка при поднятии товаров: {e}")
            return False, f"Исключение при поднятии товаров: {str(e)}"
    
    async def restore_items(self, username, password):
        """Восстановление товаров"""
        try:
            # Проверяем, есть ли активная сессия
            if username not in self.sessions:
                success, message = await self.login(username, password)
                if not success:
                    return False, f"Ошибка при входе: {message}"
            
            session = self.sessions[username]
            
            # Получаем список товаров
            async with session.get(f"{self.items_url}?status=inactive") as response:
                if response.status != 200:
                    return False, f"Ошибка при получении списка неактивных товаров: {response.status}"
                
                html = await response.text()
                soup = BeautifulSoup(html, 'html.parser')
                
                # Находим все неактивные товары
                items = soup.find_all('div', class_='item')
                
                if not items:
                    return True, "Нет товаров для восстановления"
                
                # Получаем CSRF-токен
                csrf_token = soup.find('meta', {'name': 'csrf-token'})
                if not csrf_token:
                    return False, "Не удалось получить CSRF-токен"
                csrf_token = csrf_token.get('content', '')
                
                # Восстанавливаем каждый товар
                restored_count = 0
                for item in items:
                    # Находим ID товара
                    item_id = item.get('data-id')
                    if not item_id:
                        continue
                    
                    # Проверяем, можно ли восстановить товар
                    restore_button = item.find('button', {'data-action': 'restore'})
                    if not restore_button or 'disabled' in restore_button.attrs:
                        continue
                    
                    # Восстанавливаем товар
                    restore_url = f"{self.base_url}/items/{item_id}/restore"
                    headers = {
                        'X-CSRF-TOKEN': csrf_token,
                        'X-Requested-With': 'XMLHttpRequest',
                        'Referer': f"{self.items_url}?status=inactive"
                    }
                    
                    async with session.post(restore_url, headers=headers) as restore_response:
                        if restore_response.status != 200:
                            continue
                        
                        restore_data = await restore_response.json()
                        if restore_data.get('success', False):
                            restored_count += 1
                    
                    # Делаем паузу между запросами
                    await asyncio.sleep(1)
                
                return True, f"Восстановлено товаров: {restored_count}"
                
        except Exception as e:
            logger.error(f"Ошибка при восстановлении товаров: {e}")
            return False, f"Исключение при восстановлении товаров: {str(e)}"
    
    async def get_orders(self, username, password, status='active'):
        """Получение списка заказов"""
        try:
            # Проверяем, есть ли активная сессия
            if username not in self.sessions:
                success, message = await self.login(username, password)
                if not success:
                    return False, f"Ошибка при входе: {message}"
            
            session = self.sessions[username]
            
            # Получаем список заказов
            orders_url = f"{self.orders_url}?status={status}"
            async with session.get(orders_url) as response:
                if response.status != 200:
                    return False, f"Ошибка при получении списка заказов: {response.status}"
                
                html = await response.text()
                soup = BeautifulSoup(html, 'html.parser')
                
                # Находим все заказы
                orders = soup.find_all('div', class_='order')
                
                if not orders:
                    return True, []
                
                # Парсим информацию о заказах
                orders_data = []
                for order in orders:
                    order_id = order.get('data-id')
                    if not order_id:
                        continue
                    
                    # Получаем информацию о заказе
                    order_info = {
                        'id': order_id,
                        'status': status,
                        'buyer': order.find('div', class_='buyer').text.strip() if order.find('div', class_='buyer') else '',
                        'item': order.find('div', class_='item-name').text.strip() if order.find('div', class_='item-name') else '',
                        'price': order.find('div', class_='price').text.strip() if order.find('div', class_='price') else '',
                        'date': order.find('div', class_='date').text.strip() if order.find('div', class_='date') else ''
                    }
                    
                    orders_data.append(order_info)
                
                return True, orders_data
                
        except Exception as e:
            logger.error(f"Ошибка при получении заказов: {e}")
            return False, f"Исключение при получении заказов: {str(e)}"
    
    async def complete_order(self, username, password, order_id):
        """Выполнение заказа"""
        try:
            # Проверяем, есть ли активная сессия
            if username not in self.sessions:
                success, message = await self.login(username, password)
                if not success:
                    return False, f"Ошибка при входе: {message}"
            
            session = self.sessions[username]
            
            # Получаем CSRF-токен
            async with session.get(self.orders_url) as response:
                if response.status != 200:
                    return False, f"Ошибка при получении страницы заказов: {response.status}"
                
                html = await response.text()
                soup = BeautifulSoup(html, 'html.parser')
                
                csrf_token = soup.find('meta', {'name': 'csrf-token'})
                if not csrf_token:
                    return False, "Не удалось получить CSRF-токен"
                csrf_token = csrf_token.get('content', '')
            
            # Выполняем заказ
            complete_url = f"{self.base_url}/orders/{order_id}/complete"
            headers = {
                'X-CSRF-TOKEN': csrf_token,
                'X-Requested-With': 'XMLHttpRequest',
                'Referer': self.orders_url
            }
            
            async with session.post(complete_url, headers=headers) as complete_response:
                if complete_response.status != 200:
                    return False, f"Ошибка при выполнении заказа: {complete_response.status}"
                
                complete_data = await complete_response.json()
                if not complete_data.get('success', False):
                    return False, complete_data.get('message', 'Неизвестная ошибка при выполнении заказа')
                
                return True, "Заказ успешно выполнен"
                
        except Exception as e:
            logger.error(f"Ошибка при выполнении заказа: {e}")
            return False, f"Исключение при выполнении заказа: {str(e)}"
    
    async def return_order(self, username, password, order_id, reason):
        """Возврат заказа"""
        try:
            # Проверяем, есть ли активная сессия
            if username not in self.sessions:
                success, message = await self.login(username, password)
                if not success:
                    return False, f"Ошибка при входе: {message}"
            
            session = self.sessions[username]
            
            # Получаем CSRF-токен
            async with session.get(self.orders_url) as response:
                if response.status != 200:
                    return False, f"Ошибка при получении страницы заказов: {response.status}"
                
                html = await response.text()
                soup = BeautifulSoup(html, 'html.parser')
                
                csrf_token = soup.find('meta', {'name': 'csrf-token'})
                if not csrf_token:
                    return False, "Не удалось получить CSRF-токен"
                csrf_token = csrf_token.get('content', '')
            
            # Возвращаем заказ
            return_url = f"{self.base_url}/orders/{order_id}/return"
            headers = {
                'X-CSRF-TOKEN': csrf_token,
                'X-Requested-With': 'XMLHttpRequest',
                'Referer': self.orders_url
            }
            
            data = {
                'reason': reason,
                '_token': csrf_token
            }
            
            async with session.post(return_url, headers=headers, data=data) as return_response:
                if return_response.status != 200:
                    return False, f"Ошибка при возврате заказа: {return_response.status}"
                
                return_data = await return_response.json()
                if not return_data.get('success', False):
                    return False, return_data.get('message', 'Неизвестная ошибка при возврате заказа')
                
                return True, "Заказ успешно возвращен"
                
        except Exception as e:
            logger.error(f"Ошибка при возврате заказа: {e}")
            return False, f"Исключение при возврате заказа: {str(e)}"
    
    async def get_chats(self, username, password):
        """Получение списка чатов"""
        try:
            # Проверяем, есть ли активная сессия
            if username not in self.sessions:
                success, message = await self.login(username, password)
                if not success:
                    return False, f"Ошибка при входе: {message}"
            
            session = self.sessions[username]
            
            # Получаем список чатов
            chats_url = f"{self.base_url}/chats"
            async with session.get(chats_url) as response:
                if response.status != 200:
                    return False, f"Ошибка при получении списка чатов: {response.status}"
                
                html = await response.text()
                soup = BeautifulSoup(html, 'html.parser')
                
                # Находим все чаты
                chats = soup.find_all('div', class_='chat')
                
                if not chats:
                    return True, []
                
                # Парсим информацию о чатах
                chats_data = []
                for chat in chats:
                    chat_id = chat.get('data-id')
                    if not chat_id:
                        continue
                    
                    # Получаем информацию о чате
                    chat_info = {
                        'id': chat_id,
                        'user': chat.find('div', class_='user-name').text.strip() if chat.find('div', class_='user-name') else '',
                        'last_message': chat.find('div', class_='last-message').text.strip() if chat.find('div', class_='last-message') else '',
                        'date': chat.find('div', class_='date').text.strip() if chat.find('div', class_='date') else '',
                        'unread': 'unread' in chat.get('class', [])
                    }
                    
                    chats_data.append(chat_info)
                
                return True, chats_data
                
        except Exception as e:
            logger.error(f"Ошибка при получении чатов: {e}")
            return False, f"Исключение при получении чатов: {str(e)}"
    
    async def send_message(self, username, password, chat_id, message):
        """Отправка сообщения в чат"""
        try:
            # Проверяем, есть ли активная сессия
            if username not in self.sessions:
                success, message_result = await self.login(username, password)
                if not success:
                    return False, f"Ошибка при входе: {message_result}"
            
            session = self.sessions[username]
            
            # Получаем CSRF-токен
            chat_url = f"{self.base_url}/chats/{chat_id}"
            async with session.get(chat_url) as response:
                if response.status != 200:
                    return False, f"Ошибка при получении чата: {response.status}"
                
                html = await response.text()
                soup = BeautifulSoup(html, 'html.parser')
                
                csrf_token = soup.find('meta', {'name': 'csrf-token'})
                if not csrf_token:
                    return False, "Не удалось получить CSRF-токен"
                csrf_token = csrf_token.get('content', '')
            
            # Отправляем сообщение
            send_url = f"{self.base_url}/chats/{chat_id}/send"
            headers = {
                'X-CSRF-TOKEN': csrf_token,
                'X-Requested-With': 'XMLHttpRequest',
                'Referer': chat_url
            }
            
            data = {
                'message': message,
                '_token': csrf_token
            }
            
            async with session.post(send_url, headers=headers, data=data) as send_response:
                if send_response.status != 200:
                    return False, f"Ошибка при отправке сообщения: {send_response.status}"
                
                send_data = await send_response.json()
                if not send_data.get('success', False):
                    return False, send_data.get('message', 'Неизвестная ошибка при отправке сообщения')
                
                return True, "Сообщение успешно отправлено"
                
        except Exception as e:
            logger.error(f"Ошибка при отправке сообщения: {e}")
            return False, f"Исключение при отправке сообщения: {str(e)}"
    
    async def mark_as_read(self, username, password, chat_id):
        """Отметка чата как прочитанного"""
        try:
            # Проверяем, есть ли активная сессия
            if username not in self.sessions:
                success, message = await self.login(username, password)
                if not success:
                    return False, f"Ошибка при входе: {message}"
            
            session = self.sessions[username]
            
            # Получаем CSRF-токен
            chat_url = f"{self.base_url}/chats/{chat_id}"
            async with session.get(chat_url) as response:
                if response.status != 200:
                    return False, f"Ошибка при получении чата: {response.status}"
                
                html = await response.text()
                soup = BeautifulSoup(html, 'html.parser')
                
                csrf_token = soup.find('meta', {'name': 'csrf-token'})
                if not csrf_token:
                    return False, "Не удалось получить CSRF-токен"
                csrf_token = csrf_token.get('content', '')
            
            # Отмечаем чат как прочитанный
            read_url = f"{self.base_url}/chats/{chat_id}/read"
            headers = {
                'X-CSRF-TOKEN': csrf_token,
                'X-Requested-With': 'XMLHttpRequest',
                'Referer': chat_url
            }
            
            async with session.post(read_url, headers=headers) as read_response:
                if read_response.status != 200:
                    return False, f"Ошибка при отметке чата как прочитанного: {read_response.status}"
                
                read_data = await read_response.json()
                if not read_data.get('success', False):
                    return False, read_data.get('message', 'Неизвестная ошибка при отметке чата как прочитанного')
                
                return True, "Чат отмечен как прочитанный"
                
        except Exception as e:
            logger.error(f"Ошибка при отметке чата как прочитанного: {e}")
            return False, f"Исключение при отметке чата как прочитанного: {str(e)}"
    
    async def close_all_sessions(self):
        """Закрытие всех сессий"""
        for username, session in self.sessions.items():
            try:
                await session.close()
            except Exception as e:
                logger.error(f"Ошибка при закрытии сессии для {username}: {e}")
        
        self.sessions = {}
