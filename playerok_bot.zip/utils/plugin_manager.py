#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import sys
import json
import logging
import importlib
import inspect

# Настройка логирования
logger = logging.getLogger(__name__)

class PluginManager:
    """Класс для управления плагинами"""
    
    def __init__(self):
        """Инициализация менеджера плагинов"""
        self.plugins_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "plugins")
        self.active_plugins = {}
        self.available_plugins = {}
        self.load_active_plugins()
    
    def get_all_plugins(self):
        """Получение списка всех доступных плагинов"""
        plugins = {}
        
        # Проверяем, существует ли директория плагинов
        if not os.path.exists(self.plugins_dir):
            os.makedirs(self.plugins_dir, exist_ok=True)
            return plugins
        
        # Получаем список файлов в директории плагинов
        for filename in os.listdir(self.plugins_dir):
            if filename.endswith('.py') and not filename.startswith('__'):
                plugin_name = filename[:-3]  # Убираем расширение .py
                plugins[plugin_name] = os.path.join(self.plugins_dir, filename)
        
        self.available_plugins = plugins
        return plugins
    
    def get_active_plugins(self):
        """Получение списка активных плагинов"""
        return self.active_plugins
    
    def load_plugins(self):
        """Загрузка всех плагинов"""
        plugins = self.get_all_plugins()
        
        for plugin_name, plugin_path in plugins.items():
            if plugin_name in self.active_plugins:
                continue
            
            try:
                # Добавляем директорию плагинов в sys.path
                if self.plugins_dir not in sys.path:
                    sys.path.append(self.plugins_dir)
                
                # Импортируем плагин
                plugin_module = importlib.import_module(plugin_name)
                
                # Проверяем, есть ли в модуле класс Plugin
                if hasattr(plugin_module, 'Plugin'):
                    plugin_class = getattr(plugin_module, 'Plugin')
                    
                    # Проверяем, является ли класс плагином
                    if inspect.isclass(plugin_class) and hasattr(plugin_class, 'name') and hasattr(plugin_class, 'description'):
                        # Создаем экземпляр плагина
                        plugin = plugin_class()
                        
                        # Добавляем плагин в список доступных
                        self.available_plugins[plugin_name] = {
                            'name': plugin.name,
                            'description': plugin.description,
                            'version': getattr(plugin, 'version', '1.0'),
                            'author': getattr(plugin, 'author', 'Unknown'),
                            'path': plugin_path,
                            'module': plugin_module,
                            'instance': plugin
                        }
                        
                        logger.info(f"Плагин {plugin_name} загружен")
                    else:
                        logger.warning(f"Модуль {plugin_name} не содержит корректного класса Plugin")
                else:
                    logger.warning(f"Модуль {plugin_name} не содержит класса Plugin")
            
            except Exception as e:
                logger.error(f"Ошибка при загрузке плагина {plugin_name}: {e}")
    
    def enable_plugin(self, plugin_name):
        """Включение плагина"""
        if plugin_name in self.active_plugins:
            return True, f"Плагин {plugin_name} уже активен"
        
        if plugin_name not in self.available_plugins:
            self.load_plugins()
            if plugin_name not in self.available_plugins:
                return False, f"Плагин {plugin_name} не найден"
        
        try:
            plugin_info = self.available_plugins[plugin_name]
            plugin = plugin_info['instance']
            
            # Вызываем метод enable плагина, если он существует
            if hasattr(plugin, 'enable'):
                await_result = plugin.enable()
                if inspect.isawaitable(await_result):
                    # Если метод асинхронный, возвращаем ошибку
                    return False, "Метод enable плагина должен быть синхронным"
            
            # Добавляем плагин в список активных
            self.active_plugins[plugin_name] = plugin
            
            # Сохраняем список активных плагинов
            self.save_active_plugins()
            
            logger.info(f"Плагин {plugin_name} включен")
            return True, f"Плагин {plugin_name} успешно включен"
        
        except Exception as e:
            logger.error(f"Ошибка при включении плагина {plugin_name}: {e}")
            return False, f"Ошибка при включении плагина: {str(e)}"
    
    def disable_plugin(self, plugin_name):
        """Отключение плагина"""
        if plugin_name not in self.active_plugins:
            return True, f"Плагин {plugin_name} уже отключен"
        
        try:
            plugin = self.active_plugins[plugin_name]
            
            # Вызываем метод disable плагина, если он существует
            if hasattr(plugin, 'disable'):
                await_result = plugin.disable()
                if inspect.isawaitable(await_result):
                    # Если метод асинхронный, возвращаем ошибку
                    return False, "Метод disable плагина должен быть синхронным"
            
            # Удаляем плагин из списка активных
            del self.active_plugins[plugin_name]
            
            # Сохраняем список активных плагинов
            self.save_active_plugins()
            
            logger.info(f"Плагин {plugin_name} отключен")
            return True, f"Плагин {plugin_name} успешно отключен"
        
        except Exception as e:
            logger.error(f"Ошибка при отключении плагина {plugin_name}: {e}")
            return False, f"Ошибка при отключении плагина: {str(e)}"
    
    def load_active_plugins(self):
        """Загрузка списка активных плагинов из файла"""
        active_plugins_file = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data", "active_plugins.json")
        
        if not os.path.exists(active_plugins_file):
            # Создаем директорию data, если она не существует
            os.makedirs(os.path.dirname(active_plugins_file), exist_ok=True)
            
            # Создаем пустой файл
            with open(active_plugins_file, "w", encoding="utf-8") as f:
                json.dump([], f)
            
            return
        
        try:
            with open(active_plugins_file, "r", encoding="utf-8") as f:
                active_plugins_list = json.load(f)
            
            # Загружаем все плагины
            self.load_plugins()
            
            # Активируем плагины из списка
            for plugin_name in active_plugins_list:
                self.enable_plugin(plugin_name)
            
            logger.info(f"Загружено {len(self.active_plugins)} активных плагинов")
        
        except Exception as e:
            logger.error(f"Ошибка при загрузке активных плагинов: {e}")
    
    def save_active_plugins(self):
        """Сохранение списка активных плагинов в файл"""
        active_plugins_file = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data", "active_plugins.json")
        
        try:
            # Создаем директорию data, если она не существует
            os.makedirs(os.path.dirname(active_plugins_file), exist_ok=True)
            
            # Сохраняем список активных плагинов
            with open(active_plugins_file, "w", encoding="utf-8") as f:
                json.dump(list(self.active_plugins.keys()), f)
            
            logger.info(f"Сохранено {len(self.active_plugins)} активных плагинов")
        
        except Exception as e:
            logger.error(f"Ошибка при сохранении активных плагинов: {e}")
