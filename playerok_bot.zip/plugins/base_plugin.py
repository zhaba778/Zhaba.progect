#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import sys
import json
import logging
import asyncio
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes

# Настройка логирования
logger = logging.getLogger(__name__)

class Plugin:
    """Базовый класс для плагинов"""
    
    name = "Base Plugin"
    description = "Базовый класс для плагинов"
    version = "1.0"
    author = "Playerok Bot"
    
    def __init__(self):
        """Инициализация плагина"""
        self.config = {}
        self.load_config()
    
    def enable(self):
        """Метод вызывается при включении плагина"""
        pass
    
    def disable(self):
        """Метод вызывается при отключении плагина"""
        pass
    
    async def handle_message(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Обработка сообщений"""
        return False
    
    async def handle_callback(self, update: Update, context: ContextTypes.DEFAULT_TYPE, callback_data: str):
        """Обработка callback-запросов"""
        return False
    
    def load_config(self):
        """Загрузка конфигурации плагина"""
        config_file = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data", f"{self.__class__.__name__}.json")
        
        if os.path.exists(config_file):
            try:
                with open(config_file, "r", encoding="utf-8") as f:
                    self.config = json.load(f)
            except Exception as e:
                logger.error(f"Ошибка загрузки конфигурации плагина {self.name}: {e}")
    
    def save_config(self):
        """Сохранение конфигурации плагина"""
        config_file = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data", f"{self.__class__.__name__}.json")
        
        try:
            # Создаем директорию data, если она не существует
            os.makedirs(os.path.dirname(config_file), exist_ok=True)
            
            with open(config_file, "w", encoding="utf-8") as f:
                json.dump(self.config, f, indent=4, ensure_ascii=False)
        except Exception as e:
            logger.error(f"Ошибка сохранения конфигурации плагина {self.name}: {e}")
