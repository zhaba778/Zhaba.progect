#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import sys
import json
import logging
import asyncio
import re
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes

# Импортируем базовый класс плагина
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from plugins.base_plugin import Plugin

# Настройка логирования
logger = logging.getLogger(__name__)

class Plugin(Plugin):
    """Плагин для автоматического пополнения баланса Steam"""
    
    name = "Auto Steam Balance"
    description = "Автоматическое пополнение баланса Steam без комиссии для всех СНГ регионов"
    version = "1.0"
    author = "Playerok Bot"
    
    def __init__(self):
        """Инициализация плагина"""
        super().__init__()
        
        # Настройки по умолчанию
        if not self.config:
            self.config = {
                "enabled": True,
                "auto_return": True,
                "notifications": True,
                "currencies": {
                    "RUB": 1.0,
                    "UAH": 0.37,
                    "KZT": 0.2,
                    "BYN": 30.0
                },
                "min_amount": 100,
                "max_amount": 15000,
                "wallet": "",
                "welcome_message": "Добро пожаловать в сервис автоматического пополнения Steam!\n\nУкажите ваш логин Steam и сумму пополнения.",
                "success_message": "Средства успешно отправлены!\n\nПожалуйста, оставьте отзыв, упомянув, что заказ был выполнен полностью автоматически ❤️",
                "error_message": "Произошла ошибка при обработке заказа. Пожалуйста, свяжитесь с администратором."
            }
            self.save_config()
    
    def enable(self):
        """Метод вызывается при включении плагина"""
        self.config["enabled"] = True
        self.save_config()
        logger.info("Плагин Auto Steam Balance включен")
    
    def disable(self):
        """Метод вызывается при отключении плагина"""
        self.config["enabled"] = False
        self.save_config()
        logger.info("Плагин Auto Steam Balance отключен")
    
    async def handle_message(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Обработка сообщений для автоматического пополнения Steam"""
        if not self.config["enabled"]:
            return False
        
        message_text = update.message.text
        
        # Проверяем, содержит ли сообщение информацию о заказе на пополнение Steam
        if "логин steam" in message_text.lower() or "steam" in message_text.lower():
            # Ищем логин Steam и сумму пополнения
            steam_login_match = re.search(r"логин\s*steam\s*[:\-]?\s*[«"]?([^\"»\n]+)[»\"]?", message_text, re.IGNORECASE)
            amount_match = re.search(r"сумма\s*[:\-]?\s*(\d+)\s*(руб|rub)", message_text, re.IGNORECASE)
            
            if steam_login_match and amount_match:
                steam_login = steam_login_match.group(1).strip()
                amount = int(amount_match.group(1))
                
                # Проверяем сумму
                if amount < self.config["min_amount"]:
                    await update.message.reply_text(f"❌ Минимальная сумма пополнения: {self.config['min_amount']} RUB")
                    return True
                
                if amount > self.config["max_amount"]:
                    await update.message.reply_text(f"❌ Максимальная сумма пополнения: {self.config['max_amount']} RUB")
                    return True
                
                # Отправляем сообщение для подтверждения
                keyboard = [
                    [
                        InlineKeyboardButton("✅ Подтвердить", callback_data=f"steam_confirm:{steam_login}:{amount}"),
                        InlineKeyboardButton("❌ Отменить", callback_data="steam_cancel")
                    ]
                ]
                reply_markup = InlineKeyboardMarkup(keyboard)
                
                await update.message.reply_text(
                    f"Проверьте данные:\n\n"
                    f"└ Логин Steam: «{steam_login}»\n"
                    f"└ Сумма пополнения: {amount} RUB\n\n"
                    f"Если все верно, отправьте «+» без кавычек\n"
                    f"Либо отправьте новый логин, чтобы его сменить",
                    reply_markup=reply_markup
                )
                return True
            
            # Если сообщение содержит только логин Steam
            elif steam_login_match:
                steam_login = steam_login_match.group(1).strip()
                
                # Запрашиваем сумму пополнения
                await update.message.reply_text(
                    f"Укажите сумму пополнения для логина {steam_login}.\n"
                    f"Минимальная сумма: {self.config['min_amount']} RUB\n"
                    f"Максимальная сумма: {self.config['max_amount']} RUB"
                )
                return True
            
            # Если сообщение содержит только сумму
            elif amount_match:
                amount = int(amount_match.group(1))
                
                # Проверяем сумму
                if amount < self.config["min_amount"]:
                    await update.message.reply_text(f"❌ Минимальная сумма пополнения: {self.config['min_amount']} RUB")
                    return True
                
                if amount > self.config["max_amount"]:
                    await update.message.reply_text(f"❌ Максимальная сумма пополнения: {self.config['max_amount']} RUB")
                    return True
                
                # Запрашиваем логин Steam
                await update.message.reply_text(
                    f"Укажите логин Steam для пополнения на сумму {amount} RUB."
                )
                return True
        
        # Проверяем, является ли сообщение подтверждением
        elif message_text == "+" or message_text.lower() == "подтвердить":
            # Проверяем, есть ли в контексте данные о пополнении
            if hasattr(context, 'user_data') and 'steam_login' in context.user_data and 'amount' in context.user_data:
                steam_login = context.user_data['steam_login']
                amount = context.user_data['amount']
                
                # Выполняем пополнение
                await self.process_steam_payment(update, context, steam_login, amount)
                return True
        
        # Проверяем, является ли сообщение отменой
        elif message_text.lower() == "отмена" or message_text.lower() == "отменить":
            if hasattr(context, 'user_data'):
                context.user_data.pop('steam_login', None)
                context.user_data.pop('amount', None)
            
            await update.message.reply_text("❌ Операция отменена.")
            return True
        
        return False
    
    async def handle_callback(self, update: Update, context: ContextTypes.DEFAULT_TYPE, callback_data: str):
        """Обработка callback-запросов для автоматического пополнения Steam"""
        if not self.config["enabled"]:
            return False
        
        query = update.callback_query
        
        # Обработка подтверждения пополнения
        if callback_data.startswith("steam_confirm:"):
            parts = callback_data.split(":")
            if len(parts) == 3:
                steam_login = parts[1]
                amount = int(parts[2])
                
                # Сохраняем данные в контексте
                if hasattr(context, 'user_data'):
                    context.user_data['steam_login'] = steam_login
                    context.user_data['amount'] = amount
                
                # Выполняем пополнение
                await query.edit_message_text(f"🔄 Обработка пополнения для {steam_login} на сумму {amount} RUB...")
                await self.process_steam_payment(update, context, steam_login, amount)
                return True
        
        # Обработка отмены пополнения
        elif callback_data == "steam_cancel":
            if hasattr(context, 'user_data'):
                context.user_data.pop('steam_login', None)
                context.user_data.pop('amount', None)
            
            await query.edit_message_text("❌ Операция отменена.")
            return True
        
        # Обработка настроек плагина
        elif callback_data == "steam_settings":
            keyboard = [
                [InlineKeyboardButton(f"Автовозврат: {'✅' if self.config['auto_return'] else '❌'}", callback_data="steam_toggle_return")],
                [InlineKeyboardButton(f"Уведомления: {'✅' if self.config['notifications'] else '❌'}", callback_data="steam_toggle_notifications")],
                [InlineKeyboardButton("Настройка кошелька", callback_data="steam_set_wallet")],
                [InlineKeyboardButton("Настройка сообщений", callback_data="steam_messages")],
                [InlineKeyboardButton("Настройка валют", callback_data="steam_currencies")],
                [InlineKeyboardButton("🔙 Назад", callback_data="plugins")]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            await query.edit_message_text(
                f"⚙️ *Настройки плагина Auto Steam Balance*\n\n"
                f"Текущий кошелек: `{self.config['wallet'] or 'Не указан'}`\n"
                f"Мин. сумма: {self.config['min_amount']} RUB\n"
                f"Макс. сумма: {self.config['max_amount']} RUB\n\n"
                f"Выберите параметр для изменения:",
                parse_mode='Markdown',
                reply_markup=reply_markup
            )
            return True
        
        # Обработка переключения автовозврата
        elif callback_data == "steam_toggle_return":
            self.config["auto_return"] = not self.config["auto_return"]
            self.save_config()
            
            # Обновляем меню настроек
            await self.handle_callback(update, context, "steam_settings")
            return True
        
        # Обработка переключения уведомлений
        elif callback_data == "steam_toggle_notifications":
            self.config["notifications"] = not self.config["notifications"]
            self.save_config()
            
            # Обновляем меню настроек
            await self.handle_callback(update, context, "steam_settings")
            return True
        
        return False
    
    async def process_steam_payment(self, update: Update, context: ContextTypes.DEFAULT_TYPE, steam_login, amount):
        """Обработка платежа для пополнения Steam"""
        try:
            # Здесь должна быть логика для реального пополнения Steam
            # В данном примере просто имитируем успешное пополнение
            
            # Проверяем, указан ли кошелек
            if not self.config["wallet"]:
                if update.callback_query:
                    await update.callback_query.edit_message_text(
                        "❌ Ошибка: не указан кошелек для приема платежей.\n"
                        "Пожалуйста, свяжитесь с администратором."
                    )
                else:
                    await update.message.reply_text(
                        "❌ Ошибка: не указан кошелек для приема платежей.\n"
                        "Пожалуйста, свяжитесь с администратором."
                    )
                return
            
            # Имитация успешного пополнения
            await asyncio.sleep(2)  # Имитация задержки обработки
            
            # Отправляем сообщение об успешном пополнении
            success_message = (
                f"💸 Средства успешно отправлены!\n\n"
                f"└ Логин Steam: «{steam_login}»\n"
                f"└ Сумма пополнения: {amount} RUB\n\n"
                f"Пожалуйста, оставьте отзыв, упомянув, что заказ был выполнен полностью автоматически ❤️"
            )
            
            if update.callback_query:
                await update.callback_query.edit_message_text(success_message)
            else:
                await update.message.reply_text(success_message)
            
            # Отправляем уведомление администратору, если включено
            if self.config["notifications"] and hasattr(context, 'bot'):
                admin_ids = context.bot_data.get('admin_ids', [])
                for admin_id in admin_ids:
                    try:
                        await context.bot.send_message(
                            chat_id=admin_id,
                            text=f"✅ Автоматическое пополнение Steam:\n\n"
                                 f"Логин: {steam_login}\n"
                                 f"Сумма: {amount} RUB"
                        )
                    except Exception as e:
                        logger.error(f"Ошибка отправки уведомления администратору: {e}")
            
            # Очищаем данные в контексте
            if hasattr(context, 'user_data'):
                context.user_data.pop('steam_login', None)
                context.user_data.pop('amount', None)
            
        except Exception as e:
            logger.error(f"Ошибка при обработке пополнения Steam: {e}")
            
            error_message = (
                f"❌ Произошла ошибка при обработке заказа.\n"
                f"Пожалуйста, свяжитесь с администратором.\n\n"
                f"Ошибка: {str(e)}"
            )
            
            if update.callback_query:
                await update.callback_query.edit_message_text(error_message)
            else:
                await update.message.reply_text(error_message)
