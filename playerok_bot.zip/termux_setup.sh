#!/bin/bash
# Скрипт для настройки среды Termux для Telegram бота Playerok

# Обновление репозиториев и установка необходимых пакетов
echo "Обновление репозиториев и установка необходимых пакетов..."
pkg update -y && pkg upgrade -y
pkg install -y python git wget curl nano

# Установка pip и необходимых Python-пакетов
echo "Установка pip и необходимых Python-пакетов..."
pkg install -y python-pip
pip install --upgrade pip
pip install python-telegram-bot requests beautifulsoup4 lxml aiohttp asyncio pytz

# Создание структуры директорий для бота
echo "Создание структуры директорий для бота..."
mkdir -p ~/playerok_bot/plugins
mkdir -p ~/playerok_bot/utils
mkdir -p ~/playerok_bot/data
mkdir -p ~/playerok_bot/logs

# Создание файла конфигурации
echo "Создание файла конфигурации..."
cat > ~/playerok_bot/config.py << 'EOL'
# Конфигурация бота
import os
import json

# Базовые настройки
BOT_TOKEN = "YOUR_BOT_TOKEN"  # Замените на ваш токен бота
ADMIN_IDS = []  # Список ID администраторов бота

# Настройки Playerok
PLAYEROK_USERNAME = ""
PLAYEROK_PASSWORD = ""

# Настройки прокси (если необходимо)
PROXY_ENABLED = False
PROXY_URL = ""

# Настройки автоподнятия
AUTO_BUMP_ENABLED = True
AUTO_BUMP_INTERVAL = 3600  # в секундах (1 час)

# Настройки автовосстановления товаров
AUTO_RESTORE_ENABLED = True
AUTO_RESTORE_INTERVAL = 7200  # в секундах (2 часа)

# Настройки уведомлений
NOTIFICATIONS_ENABLED = True
NOTIFICATION_SOUND = True

# Настройки автоответа
AUTO_REPLY_ENABLED = True

# Пути к файлам данных
DATA_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
LOGS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "logs")
PLUGINS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "plugins")

# Функции для работы с конфигурацией
def save_config():
    """Сохраняет текущую конфигурацию в файл"""
    config_data = {
        "bot_token": BOT_TOKEN,
        "admin_ids": ADMIN_IDS,
        "playerok_username": PLAYEROK_USERNAME,
        "playerok_password": PLAYEROK_PASSWORD,
        "proxy_enabled": PROXY_ENABLED,
        "proxy_url": PROXY_URL,
        "auto_bump_enabled": AUTO_BUMP_ENABLED,
        "auto_bump_interval": AUTO_BUMP_INTERVAL,
        "auto_restore_enabled": AUTO_RESTORE_ENABLED,
        "auto_restore_interval": AUTO_RESTORE_INTERVAL,
        "notifications_enabled": NOTIFICATIONS_ENABLED,
        "notification_sound": NOTIFICATION_SOUND,
        "auto_reply_enabled": AUTO_REPLY_ENABLED
    }
    
    with open(os.path.join(DATA_DIR, "config.json"), "w", encoding="utf-8") as f:
        json.dump(config_data, f, indent=4, ensure_ascii=False)

def load_config():
    """Загружает конфигурацию из файла"""
    global BOT_TOKEN, ADMIN_IDS, PLAYEROK_USERNAME, PLAYEROK_PASSWORD
    global PROXY_ENABLED, PROXY_URL, AUTO_BUMP_ENABLED, AUTO_BUMP_INTERVAL
    global AUTO_RESTORE_ENABLED, AUTO_RESTORE_INTERVAL, NOTIFICATIONS_ENABLED
    global NOTIFICATION_SOUND, AUTO_REPLY_ENABLED
    
    config_file = os.path.join(DATA_DIR, "config.json")
    if os.path.exists(config_file):
        with open(config_file, "r", encoding="utf-8") as f:
            config_data = json.load(f)
            
        BOT_TOKEN = config_data.get("bot_token", BOT_TOKEN)
        ADMIN_IDS = config_data.get("admin_ids", ADMIN_IDS)
        PLAYEROK_USERNAME = config_data.get("playerok_username", PLAYEROK_USERNAME)
        PLAYEROK_PASSWORD = config_data.get("playerok_password", PLAYEROK_PASSWORD)
        PROXY_ENABLED = config_data.get("proxy_enabled", PROXY_ENABLED)
        PROXY_URL = config_data.get("proxy_url", PROXY_URL)
        AUTO_BUMP_ENABLED = config_data.get("auto_bump_enabled", AUTO_BUMP_ENABLED)
        AUTO_BUMP_INTERVAL = config_data.get("auto_bump_interval", AUTO_BUMP_INTERVAL)
        AUTO_RESTORE_ENABLED = config_data.get("auto_restore_enabled", AUTO_RESTORE_ENABLED)
        AUTO_RESTORE_INTERVAL = config_data.get("auto_restore_interval", AUTO_RESTORE_INTERVAL)
        NOTIFICATIONS_ENABLED = config_data.get("notifications_enabled", NOTIFICATIONS_ENABLED)
        NOTIFICATION_SOUND = config_data.get("notification_sound", NOTIFICATION_SOUND)
        AUTO_REPLY_ENABLED = config_data.get("auto_reply_enabled", AUTO_REPLY_ENABLED)

# Создаем директории, если они не существуют
os.makedirs(DATA_DIR, exist_ok=True)
os.makedirs(LOGS_DIR, exist_ok=True)
os.makedirs(PLUGINS_DIR, exist_ok=True)

# Загружаем конфигурацию при импорте модуля
try:
    load_config()
except Exception as e:
    print(f"Ошибка загрузки конфигурации: {e}")
    # Сохраняем дефолтную конфигурацию
    save_config()
EOL

# Создание файла запуска бота
echo "Создание файла запуска бота..."
cat > ~/playerok_bot/run_bot.sh << 'EOL'
#!/bin/bash
cd ~/playerok_bot
python main.py
EOL

# Делаем скрипт запуска исполняемым
chmod +x ~/playerok_bot/run_bot.sh

echo "Настройка среды Termux завершена!"
echo "Теперь вы можете перейти в директорию бота: cd ~/playerok_bot"
echo "И запустить бота: ./run_bot.sh"
