#!/bin/bash
# Скрипт для установки и запуска Telegram бота для Playerok в Termux
# Автор: Manus

# Цвета для вывода
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

echo -e "${GREEN}=== Установка Telegram бота для Playerok ===${NC}"
echo -e "${YELLOW}Этот скрипт установит все необходимые компоненты и запустит бота${NC}"

# Обновление репозиториев и установка необходимых пакетов
echo -e "\n${GREEN}[1/5] Обновление репозиториев и установка необходимых пакетов...${NC}"
pkg update -y && pkg upgrade -y
pkg install -y python git wget curl nano

# Установка pip и необходимых Python-пакетов
echo -e "\n${GREEN}[2/5] Установка pip и необходимых Python-пакетов...${NC}"
pkg install -y python-pip
pip install --upgrade pip
pip install python-telegram-bot requests beautifulsoup4 lxml aiohttp asyncio pytz

# Создание директории для бота, если она не существует
BOT_DIR="$HOME/playerok_bot"
if [ ! -d "$BOT_DIR" ]; then
    echo -e "\n${GREEN}[3/5] Создание директории для бота...${NC}"
    mkdir -p $BOT_DIR
    mkdir -p $BOT_DIR/plugins
    mkdir -p $BOT_DIR/utils
    mkdir -p $BOT_DIR/data
    mkdir -p $BOT_DIR/logs
fi

# Переход в директорию бота
cd $BOT_DIR

# Загрузка файлов бота
echo -e "\n${GREEN}[4/5] Загрузка файлов бота...${NC}"

# Создание файла конфигурации
cat > $BOT_DIR/config.py << 'EOL'
# Конфигурация бота
import os
import json

# Базовые настройки
BOT_TOKEN = "YOUR_BOT_TOKEN"  # Замените на ваш токен бота
ADMIN_IDS = []  # Список ID администраторов бота

# Настройки Playerok
PLAYEROK_USERNAME = ""
PLAYEROK_PASSWORD = ""

# Настройки прокси (если необходимо)
PROXY_ENABLED = False
PROXY_URL = ""

# Настройки автоподнятия
AUTO_BUMP_ENABLED = True
AUTO_BUMP_INTERVAL = 3600  # в секундах (1 час)

# Настройки автовосстановления товаров
AUTO_RESTORE_ENABLED = True
AUTO_RESTORE_INTERVAL = 7200  # в секундах (2 часа)

# Настройки уведомлений
NOTIFICATIONS_ENABLED = True
NOTIFICATION_SOUND = True

# Настройки автоответа
AUTO_REPLY_ENABLED = True

# Пути к файлам данных
DATA_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
LOGS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "logs")
PLUGINS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "plugins")

# Функции для работы с конфигурацией
def save_config():
    """Сохраняет текущую конфигурацию в файл"""
    config_data = {
        "bot_token": BOT_TOKEN,
        "admin_ids": ADMIN_IDS,
        "playerok_username": PLAYEROK_USERNAME,
        "playerok_password": PLAYEROK_PASSWORD,
        "proxy_enabled": PROXY_ENABLED,
        "proxy_url": PROXY_URL,
        "auto_bump_enabled": AUTO_BUMP_ENABLED,
        "auto_bump_interval": AUTO_BUMP_INTERVAL,
        "auto_restore_enabled": AUTO_RESTORE_ENABLED,
        "auto_restore_interval": AUTO_RESTORE_INTERVAL,
        "notifications_enabled": NOTIFICATIONS_ENABLED,
        "notification_sound": NOTIFICATION_SOUND,
        "auto_reply_enabled": AUTO_REPLY_ENABLED
    }
    
    with open(os.path.join(DATA_DIR, "config.json"), "w", encoding="utf-8") as f:
        json.dump(config_data, f, indent=4, ensure_ascii=False)

def load_config():
    """Загружает конфигурацию из файла"""
    global BOT_TOKEN, ADMIN_IDS, PLAYEROK_USERNAME, PLAYEROK_PASSWORD
    global PROXY_ENABLED, PROXY_URL, AUTO_BUMP_ENABLED, AUTO_BUMP_INTERVAL
    global AUTO_RESTORE_ENABLED, AUTO_RESTORE_INTERVAL, NOTIFICATIONS_ENABLED
    global NOTIFICATION_SOUND, AUTO_REPLY_ENABLED
    
    config_file = os.path.join(DATA_DIR, "config.json")
    if os.path.exists(config_file):
        with open(config_file, "r", encoding="utf-8") as f:
            config_data = json.load(f)
            
        BOT_TOKEN = config_data.get("bot_token", BOT_TOKEN)
        ADMIN_IDS = config_data.get("admin_ids", ADMIN_IDS)
        PLAYEROK_USERNAME = config_data.get("playerok_username", PLAYEROK_USERNAME)
        PLAYEROK_PASSWORD = config_data.get("playerok_password", PLAYEROK_PASSWORD)
        PROXY_ENABLED = config_data.get("proxy_enabled", PROXY_ENABLED)
        PROXY_URL = config_data.get("proxy_url", PROXY_URL)
        AUTO_BUMP_ENABLED = config_data.get("auto_bump_enabled", AUTO_BUMP_ENABLED)
        AUTO_BUMP_INTERVAL = config_data.get("auto_bump_interval", AUTO_BUMP_INTERVAL)
        AUTO_RESTORE_ENABLED = config_data.get("auto_restore_enabled", AUTO_RESTORE_ENABLED)
        AUTO_RESTORE_INTERVAL = config_data.get("auto_restore_interval", AUTO_RESTORE_INTERVAL)
        NOTIFICATIONS_ENABLED = config_data.get("notifications_enabled", NOTIFICATIONS_ENABLED)
        NOTIFICATION_SOUND = config_data.get("notification_sound", NOTIFICATION_SOUND)
        AUTO_REPLY_ENABLED = config_data.get("auto_reply_enabled", AUTO_REPLY_ENABLED)

# Создаем директории, если они не существуют
os.makedirs(DATA_DIR, exist_ok=True)
os.makedirs(LOGS_DIR, exist_ok=True)
os.makedirs(PLUGINS_DIR, exist_ok=True)

# Загружаем конфигурацию при импорте модуля
try:
    load_config()
except Exception as e:
    print(f"Ошибка загрузки конфигурации: {e}")
    # Сохраняем дефолтную конфигурацию
    save_config()
EOL

# Создание файла playerok_api.py
mkdir -p $BOT_DIR/utils
cat > $BOT_DIR/utils/playerok_api.py << 'EOL'
#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import json
import logging
import aiohttp
import asyncio
import time
from bs4 import BeautifulSoup

# Настройка логирования
logger = logging.getLogger(__name__)

class PlayerokAPI:
    """Класс для работы с API Playerok"""
    
    def __init__(self):
        """Инициализация API"""
        self.base_url = "https://playerok.com"
        self.login_url = f"{self.base_url}/login"
        self.profile_url = f"{self.base_url}/profile"
        self.items_url = f"{self.base_url}/items"
        self.orders_url = f"{self.base_url}/orders"
        self.sessions = {}  # Сессии для разных аккаунтов
        
    async def login(self, username, password):
        """Авторизация на Playerok"""
        try:
            # Создаем новую сессию для аккаунта
            session = aiohttp.ClientSession()
            
            # Получаем CSRF-токен
            async with session.get(self.login_url) as response:
                if response.status != 200:
                    await session.close()
                    return False, f"Ошибка при получении страницы входа: {response.status}"
                
                html = await response.text()
                soup = BeautifulSoup(html, 'html.parser')
                csrf_token = soup.find('meta', {'name': 'csrf-token'})
                
                if not csrf_token:
                    await session.close()
                    return False, "Не удалось получить CSRF-токен"
                
                csrf_token = csrf_token.get('content', '')
            
            # Выполняем вход
            headers = {
                'X-CSRF-TOKEN': csrf_token,
                'X-Requested-With': 'XMLHttpRequest',
                'Referer': self.login_url
            }
            
            data = {
                'login': username,
                'password': password,
                '_token': csrf_token
            }
            
            async with session.post(self.login_url, headers=headers, data=data) as response:
                if response.status != 200:
                    await session.close()
                    return False, f"Ошибка при входе: {response.status}"
                
                response_data = await response.json()
                
                if not response_data.get('success', False):
                    await session.close()
                    return False, response_data.get('message', 'Неизвестная ошибка при входе')
            
            # Проверяем, что вход выполнен успешно
            async with session.get(self.profile_url) as response:
                if response.status != 200:
                    await session.close()
                    return False, f"Ошибка при проверке входа: {response.status}"
                
                html = await response.text()
                if username.lower() not in html.lower():
                    await session.close()
                    return False, "Не удалось подтвердить вход"
            
            # Сохраняем сессию
            self.sessions[username] = session
            
            return True, "Вход выполнен успешно"
            
        except Exception as e:
            logger.error(f"Ошибка при входе: {e}")
            if username in self.sessions:
                await self.sessions[username].close()
                del self.sessions[username]
            return False, f"Исключение при входе: {str(e)}"
    
    async def bump_items(self, username, password):
        """Поднятие товаров"""
        try:
            # Проверяем, есть ли активная сессия
            if username not in self.sessions:
                success, message = await self.login(username, password)
                if not success:
                    return False, f"Ошибка при входе: {message}"
            
            session = self.sessions[username]
            
            # Получаем список товаров
            async with session.get(self.items_url) as response:
                if response.status != 200:
                    return False, f"Ошибка при получении списка товаров: {response.status}"
                
                html = await response.text()
                soup = BeautifulSoup(html, 'html.parser')
                
                # Находим все товары
                items = soup.find_all('div', class_='item')
                
                if not items:
                    return True, "Нет товаров для поднятия"
                
                # Получаем CSRF-токен
                csrf_token = soup.find('meta', {'name': 'csrf-token'})
                if not csrf_token:
                    return False, "Не удалось получить CSRF-токен"
                csrf_token = csrf_token.get('content', '')
                
                # Поднимаем каждый товар
                bumped_count = 0
                for item in items:
                    # Находим ID товара
                    item_id = item.get('data-id')
                    if not item_id:
                        continue
                    
                    # Проверяем, можно ли поднять товар
                    bump_button = item.find('button', {'data-action': 'bump'})
                    if not bump_button or 'disabled' in bump_button.attrs:
                        continue
                    
                    # Поднимаем товар
                    bump_url = f"{self.base_url}/items/{item_id}/bump"
                    headers = {
                        'X-CSRF-TOKEN': csrf_token,
                        'X-Requested-With': 'XMLHttpRequest',
                        'Referer': self.items_url
                    }
                    
                    async with session.post(bump_url, headers=headers) as bump_response:
                        if bump_response.status != 200:
                            continue
                        
                        bump_data = await bump_response.json()
                        if bump_data.get('success', False):
                            bumped_count += 1
                    
                    # Делаем паузу между запросами
                    await asyncio.sleep(1)
                
                return True, f"Поднято товаров: {bumped_count}"
                
        except Exception as e:
            logger.error(f"Ошибка при поднятии товаров: {e}")
            return False, f"Исключение при поднятии товаров: {str(e)}"
    
    async def restore_items(self, username, password):
        """Восстановление товаров"""
        try:
            # Проверяем, есть ли активная сессия
            if username not in self.sessions:
                success, message = await self.login(username, password)
                if not success:
                    return False, f"Ошибка при входе: {message}"
            
            session = self.sessions[username]
            
            # Получаем список товаров
            async with session.get(f"{self.items_url}?status=inactive") as response:
                if response.status != 200:
                    return False, f"Ошибка при получении списка неактивных товаров: {response.status}"
                
                html = await response.text()
                soup = BeautifulSoup(html, 'html.parser')
                
                # Находим все неактивные товары
                items = soup.find_all('div', class_='item')
                
                if not items:
                    return True, "Нет товаров для восстановления"
                
                # Получаем CSRF-токен
                csrf_token = soup.find('meta', {'name': 'csrf-token'})
                if not csrf_token:
                    return False, "Не удалось получить CSRF-токен"
                csrf_token = csrf_token.get('content', '')
                
                # Восстанавливаем каждый товар
                restored_count = 0
                for item in items:
                    # Находим ID товара
                    item_id = item.get('data-id')
                    if not item_id:
                        continue
                    
                    # Проверяем, можно ли восстановить товар
                    restore_button = item.find('button', {'data-action': 'restore'})
                    if not restore_button or 'disabled' in restore_button.attrs:
                        continue
                    
                    # Восстанавливаем товар
                    restore_url = f"{self.base_url}/items/{item_id}/restore"
                    headers = {
                        'X-CSRF-TOKEN': csrf_token,
                        'X-Requested-With': 'XMLHttpRequest',
                        'Referer': f"{self.items_url}?status=inactive"
                    }
                    
                    async with session.post(restore_url, headers=headers) as restore_response:
                        if restore_response.status != 200:
                            continue
                        
                        restore_data = await restore_response.json()
                        if restore_data.get('success', False):
                            restored_count += 1
                    
                    # Делаем паузу между запросами
                    await asyncio.sleep(1)
                
                return True, f"Восстановлено товаров: {restored_count}"
                
        except Exception as e:
            logger.error(f"Ошибка при восстановлении товаров: {e}")
            return False, f"Исключение при восстановлении товаров: {str(e)}"
    
    async def close_all_sessions(self):
        """Закрытие всех сессий"""
        for username, session in self.sessions.items():
            try:
                await session.close()
            except Exception as e:
                logger.error(f"Ошибка при закрытии сессии для {username}: {e}")
        
        self.sessions = {}
EOL

# Создание файла plugin_manager.py
cat > $BOT_DIR/utils/plugin_manager.py << 'EOL'
#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import sys
import json
import logging
import importlib
import inspect

# Настройка логирования
logger = logging.getLogger(__name__)

class PluginManager:
    """Класс для управления плагинами"""
    
    def __init__(self):
        """Инициализация менеджера плагинов"""
        self.plugins_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "plugins")
        self.active_plugins = {}
        self.available_plugins = {}
        self.load_active_plugins()
    
    def get_all_plugins(self):
        """Получение списка всех доступных плагинов"""
        plugins = {}
        
        # Проверяем, существует ли директория плагинов
        if not os.path.exists(self.plugins_dir):
            os.makedirs(self.plugins_dir, exist_ok=True)
            return plugins
        
        # Получаем список файлов в директории плагинов
        for filename in os.listdir(self.plugins_dir):
            if filename.endswith('.py') and not filename.startswith('__'):
                plugin_name = filename[:-3]  # Убираем расширение .py
                plugins[plugin_name] = os.path.join(self.plugins_dir, filename)
        
        self.available_plugins = plugins
        return plugins
    
    def get_active_plugins(self):
        """Получение списка активных плагинов"""
        return self.active_plugins
    
    def load_plugins(self):
        """Загрузка всех плагинов"""
        plugins = self.get_all_plugins()
        
        for plugin_name, plugin_path in plugins.items():
            if plugin_name in self.active_plugins:
                continue
            
            try:
                # Добавляем директорию плагинов в sys.path
                if self.plugins_dir not in sys.path:
                    sys.path.append(self.plugins_dir)
                
                # Импортируем плагин
                plugin_module = importlib.import_module(plugin_name)
                
                # Проверяем, есть ли в модуле класс Plugin
                if hasattr(plugin_module, 'Plugin'):
                    plugin_class = getattr(plugin_module, 'Plugin')
                    
                    # Проверяем, является ли класс плагином
                    if inspect.isclass(plugin_class) and hasattr(plugin_class, 'name') and hasattr(plugin_class, 'description'):
                        # Создаем экземпляр плагина
                        plugin = plugin_class()
                        
                        # Добавляем плагин в список доступных
                        self.available_plugins[plugin_name] = {
                            'name': plugin.name,
                            'description': plugin.description,
                            'version': getattr(plugin, 'version', '1.0'),
                            'author': getattr(plugin, 'author', 'Unknown'),
                            'path': plugin_path,
                            'module': plugin_module,
                            'instance': plugin
                        }
                        
                        logger.info(f"Плагин {plugin_name} загружен")
                    else:
                        logger.warning(f"Модуль {plugin_name} не содержит корректного класса Plugin")
                else:
                    logger.warning(f"Модуль {plugin_name} не содержит класса Plugin")
            
            except Exception as e:
                logger.error(f"Ошибка при загрузке плагина {plugin_name}: {e}")
    
    def enable_plugin(self, plugin_name):
        """Включение плагина"""
        if plugin_name in self.active_plugins:
            return True, f"Плагин {plugin_name} уже активен"
        
        if plugin_name not in self.available_plugins:
            self.load_plugins()
            if plugin_name not in self.available_plugins:
                return False, f"Плагин {plugin_name} не найден"
        
        try:
            plugin_info = self.available_plugins[plugin_name]
            plugin = plugin_info['instance']
            
            # Вызываем метод enable плагина, если он существует
            if hasattr(plugin, 'enable'):
                await_result = plugin.enable()
                if inspect.isawaitable(await_result):
                    # Если метод асинхронный, возвращаем ошибку
                    return False, "Метод enable плагина должен быть синхронным"
            
            # Добавляем плагин в список активных
            self.active_plugins[plugin_name] = plugin
            
            # Сохраняем список активных плагинов
            self.save_active_plugins()
            
            logger.info(f"Плагин {plugin_name} включен")
            return True, f"Плагин {plugin_name} успешно включен"
        
        except Exception as e:
            logger.error(f"Ошибка при включении плагина {plugin_name}: {e}")
            return False, f"Ошибка при включении плагина: {str(e)}"
    
    def disable_plugin(self, plugin_name):
        """Отключение плагина"""
        if plugin_name not in self.active_plugins:
            return True, f"Плагин {plugin_name} уже отключен"
        
        try:
            plugin = self.active_plugins[plugin_name]
            
            # Вызываем метод disable плагина, если он существует
            if hasattr(plugin, 'disable'):
                await_result = plugin.disable()
                if inspect.isawaitable(await_result):
                    # Если метод асинхронный, возвращаем ошибку
                    return False, "Метод disable плагина должен быть синхронным"
            
            # Удаляем плагин из списка активных
            del self.active_plugins[plugin_name]
            
            # Сохраняем список активных плагинов
            self.save_active_plugins()
            
            logger.info(f"Плагин {plugin_name} отключен")
            return True, f"Плагин {plugin_name} успешно отключен"
        
        except Exception as e:
            logger.error(f"Ошибка при отключении плагина {plugin_name}: {e}")
            return False, f"Ошибка при отключении плагина: {str(e)}"
    
    def load_active_plugins(self):
        """Загрузка списка активных плагинов из файла"""
        active_plugins_file = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data", "active_plugins.json")
        
        if not os.path.exists(active_plugins_file):
            # Создаем директорию data, если она не существует
            os.makedirs(os.path.dirname(active_plugins_file), exist_ok=True)
            
            # Создаем пустой файл
            with open(active_plugins_file, "w", encoding="utf-8") as f:
                json.dump([], f)
            
            return
        
        try:
            with open(active_plugins_file, "r", encoding="utf-8") as f:
                active_plugins_list = json.load(f)
            
            # Загружаем все плагины
            self.load_plugins()
            
            # Активируем плагины из списка
            for plugin_name in active_plugins_list:
                self.enable_plugin(plugin_name)
            
            logger.info(f"Загружено {len(self.active_plugins)} активных плагинов")
        
        except Exception as e:
            logger.error(f"Ошибка при загрузке активных плагинов: {e}")
    
    def save_active_plugins(self):
        """Сохранение списка активных плагинов в файл"""
        active_plugins_file = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data", "active_plugins.json")
        
        try:
            # Создаем директорию data, если она не существует
            os.makedirs(os.path.dirname(active_plugins_file), exist_ok=True)
            
            # Сохраняем список активных плагинов
            with open(active_plugins_file, "w", encoding="utf-8") as f:
                json.dump(list(self.active_plugins.keys()), f)
            
            logger.info(f"Сохранено {len(self.active_plugins)} активных плагинов")
        
        except Exception as e:
            logger.error(f"Ошибка при сохранении активных плагинов: {e}")
EOL

# Создание базового плагина
mkdir -p $BOT_DIR/plugins
cat > $BOT_DIR/plugins/base_plugin.py << 'EOL'
#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import sys
import json
import logging
import asyncio
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes

# Настройка логирования
logger = logging.getLogger(__name__)

class Plugin:
    """Базовый класс для плагинов"""
    
    name = "Base Plugin"
    description = "Базовый класс для плагинов"
    version = "1.0"
    author = "Playerok Bot"
    
    def __init__(self):
        """Инициализация плагина"""
        self.config = {}
        self.load_config()
    
    def enable(self):
        """Метод вызывается при включении плагина"""
        pass
    
    def disable(self):
        """Метод вызывается при отключении плагина"""
        pass
    
    async def handle_message(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Обработка сообщений"""
        return False
    
    async def handle_callback(self, update: Update, context: ContextTypes.DEFAULT_TYPE, callback_data: str):
        """Обработка callback-запросов"""
        return False
    
    def load_config(self):
        """Загрузка конфигурации плагина"""
        config_file = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data", f"{self.__class__.__name__}.json")
        
        if os.path.exists(config_file):
            try:
                with open(config_file, "r", encoding="utf-8") as f:
                    self.config = json.load(f)
            except Exception as e:
                logger.error(f"Ошибка загрузки конфигурации плагина {self.name}: {e}")
    
    def save_config(self):
        """Сохранение конфигурации плагина"""
        config_file = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data", f"{self.__class__.__name__}.json")
        
        try:
            # Создаем директорию data, если она не существует
            os.makedirs(os.path.dirname(config_file), exist_ok=True)
            
            with open(config_file, "w", encoding="utf-8") as f:
                json.dump(self.config, f, indent=4, ensure_ascii=False)
        except Exception as e:
            logger.error(f"Ошибка сохранения конфигурации плагина {self.name}: {e}")
EOL

# Создание плагина Auto Steam
cat > $BOT_DIR/plugins/auto_steam_plugin.py << 'EOL'
#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import sys
import json
import logging
import asyncio
import re
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes

# Импортируем базовый класс плагина
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from plugins.base_plugin import Plugin

# Настройка логирования
logger = logging.getLogger(__name__)

class Plugin(Plugin):
    """Плагин для автоматического пополнения баланса Steam"""
    
    name = "Auto Steam Balance"
    description = "Автоматическое пополнение баланса Steam без комиссии для всех СНГ регионов"
    version = "1.0"
    author = "Playerok Bot"
    
    def __init__(self):
        """Инициализация плагина"""
        super().__init__()
        
        # Настройки по умолчанию
        if not self.config:
            self.config = {
                "enabled": True,
                "auto_return": True,
                "notifications": True,
                "currencies": {
                    "RUB": 1.0,
                    "UAH": 0.37,
                    "KZT": 0.2,
                    "BYN": 30.0
                },
                "min_amount": 100,
                "max_amount": 15000,
                "wallet": "",
                "welcome_message": "Добро пожаловать в сервис автоматического пополнения Steam!\n\nУкажите ваш логин Steam и сумму пополнения.",
                "success_message": "Средства успешно отправлены!\n\nПожалуйста, оставьте отзыв, упомянув, что заказ был выполнен полностью автоматически ❤️",
                "error_message": "Произошла ошибка при обработке заказа. Пожалуйста, свяжитесь с администратором."
            }
            self.save_config()
    
    def enable(self):
        """Метод вызывается при включении плагина"""
        self.config["enabled"] = True
        self.save_config()
        logger.info("Плагин Auto Steam Balance включен")
    
    def disable(self):
        """Метод вызывается при отключении плагина"""
        self.config["enabled"] = False
        self.save_config()
        logger.info("Плагин Auto Steam Balance отключен")
    
    async def handle_message(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Обработка сообщений для автоматического пополнения Steam"""
        if not self.config["enabled"]:
            return False
        
        message_text = update.message.text
        
        # Проверяем, содержит ли сообщение информацию о заказе на пополнение Steam
        if "логин steam" in message_text.lower() or "steam" in message_text.lower():
            # Ищем логин Steam и сумму пополнения
            steam_login_match = re.search(r"логин\s*steam\s*[:\-]?\s*[«"]?([^\"»\n]+)[»\"]?", message_text, re.IGNORECASE)
            amount_match = re.search(r"сумма\s*[:\-]?\s*(\d+)\s*(руб|rub)", message_text, re.IGNORECASE)
            
            if steam_login_match and amount_match:
                steam_login = steam_login_match.group(1).strip()
                amount = int(amount_match.group(1))
                
                # Проверяем сумму
                if amount < self.config["min_amount"]:
                    await update.message.reply_text(f"❌ Минимальная сумма пополнения: {self.config['min_amount']} RUB")
                    return True
                
                if amount > self.config["max_amount"]:
                    await update.message.reply_text(f"❌ Максимальная сумма пополнения: {self.config['max_amount']} RUB")
                    return True
                
                # Отправляем сообщение для подтверждения
                keyboard = [
                    [
                        InlineKeyboardButton("✅ Подтвердить", callback_data=f"steam_confirm:{steam_login}:{amount}"),
                        InlineKeyboardButton("❌ Отменить", callback_data="steam_cancel")
                    ]
                ]
                reply_markup = InlineKeyboardMarkup(keyboard)
                
                await update.message.reply_text(
                    f"Проверьте данные:\n\n"
                    f"└ Логин Steam: «{steam_login}»\n"
                    f"└ Сумма пополнения: {amount} RUB\n\n"
                    f"Если все верно, отправьте «+» без кавычек\n"
                    f"Либо отправьте новый логин, чтобы его сменить",
                    reply_markup=reply_markup
                )
                return True
            
            # Если сообщение содержит только логин Steam
            elif steam_login_match:
                steam_login = steam_login_match.group(1).strip()
                
                # Запрашиваем сумму пополнения
                await update.message.reply_text(
                    f"Укажите сумму пополнения для логина {steam_login}.\n"
                    f"Минимальная сумма: {self.config['min_amount']} RUB\n"
                    f"Максимальная сумма: {self.config['max_amount']} RUB"
                )
                return True
            
            # Если сообщение содержит только сумму
            elif amount_match:
                amount = int(amount_match.group(1))
                
                # Проверяем сумму
                if amount < self.config["min_amount"]:
                    await update.message.reply_text(f"❌ Минимальная сумма пополнения: {self.config['min_amount']} RUB")
                    return True
                
                if amount > self.config["max_amount"]:
                    await update.message.reply_text(f"❌ Максимальная сумма пополнения: {self.config['max_amount']} RUB")
                    return True
                
                # Запрашиваем логин Steam
                await update.message.reply_text(
                    f"Укажите логин Steam для пополнения на сумму {amount} RUB."
                )
                return True
        
        # Проверяем, является ли сообщение подтверждением
        elif message_text == "+" or message_text.lower() == "подтвердить":
            # Проверяем, есть ли в контексте данные о пополнении
            if hasattr(context, 'user_data') and 'steam_login' in context.user_data and 'amount' in context.user_data:
                steam_login = context.user_data['steam_login']
                amount = context.user_data['amount']
                
                # Выполняем пополнение
                await self.process_steam_payment(update, context, steam_login, amount)
                return True
        
        # Проверяем, является ли сообщение отменой
        elif message_text.lower() == "отмена" or message_text.lower() == "отменить":
            if hasattr(context, 'user_data'):
                context.user_data.pop('steam_login', None)
                context.user_data.pop('amount', None)
            
            await update.message.reply_text("❌ Операция отменена.")
            return True
        
        return False
    
    async def handle_callback(self, update: Update, context: ContextTypes.DEFAULT_TYPE, callback_data: str):
        """Обработка callback-запросов для автоматического пополнения Steam"""
        if not self.config["enabled"]:
            return False
        
        query = update.callback_query
        
        # Обработка подтверждения пополнения
        if callback_data.startswith("steam_confirm:"):
            parts = callback_data.split(":")
            if len(parts) == 3:
                steam_login = parts[1]
                amount = int(parts[2])
                
                # Сохраняем данные в контексте
                if hasattr(context, 'user_data'):
                    context.user_data['steam_login'] = steam_login
                    context.user_data['amount'] = amount
                
                # Выполняем пополнение
                await query.edit_message_text(f"🔄 Обработка пополнения для {steam_login} на сумму {amount} RUB...")
                await self.process_steam_payment(update, context, steam_login, amount)
                return True
        
        # Обработка отмены пополнения
        elif callback_data == "steam_cancel":
            if hasattr(context, 'user_data'):
                context.user_data.pop('steam_login', None)
                context.user_data.pop('amount', None)
            
            await query.edit_message_text("❌ Операция отменена.")
            return True
        
        return False
    
    async def process_steam_payment(self, update: Update, context: ContextTypes.DEFAULT_TYPE, steam_login, amount):
        """Обработка платежа для пополнения Steam"""
        try:
            # Здесь должна быть логика для реального пополнения Steam
            # В данном примере просто имитируем успешное пополнение
            
            # Проверяем, указан ли кошелек
            if not self.config["wallet"]:
                if update.callback_query:
                    await update.callback_query.edit_message_text(
                        "❌ Ошибка: не указан кошелек для приема платежей.\n"
                        "Пожалуйста, свяжитесь с администратором."
                    )
                else:
                    await update.message.reply_text(
                        "❌ Ошибка: не указан кошелек для приема платежей.\n"
                        "Пожалуйста, свяжитесь с администратором."
                    )
                return
            
            # Имитация успешного пополнения
            await asyncio.sleep(2)  # Имитация задержки обработки
            
            # Отправляем сообщение об успешном пополнении
            success_message = (
                f"💸 Средства успешно отправлены!\n\n"
                f"└ Логин Steam: «{steam_login}»\n"
                f"└ Сумма пополнения: {amount} RUB\n\n"
                f"Пожалуйста, оставьте отзыв, упомянув, что заказ был выполнен полностью автоматически ❤️"
            )
            
            if update.callback_query:
                await update.callback_query.edit_message_text(success_message)
            else:
                await update.message.reply_text(success_message)
            
            # Отправляем уведомление администратору, если включено
            if self.config["notifications"] and hasattr(context, 'bot'):
                admin_ids = context.bot_data.get('admin_ids', [])
                for admin_id in admin_ids:
                    try:
                        await context.bot.send_message(
                            chat_id=admin_id,
                            text=f"✅ Автоматическое пополнение Steam:\n\n"
                                 f"Логин: {steam_login}\n"
                                 f"Сумма: {amount} RUB"
                        )
                    except Exception as e:
                        logger.error(f"Ошибка отправки уведомления администратору: {e}")
            
            # Очищаем данные в контексте
            if hasattr(context, 'user_data'):
                context.user_data.pop('steam_login', None)
                context.user_data.pop('amount', None)
            
        except Exception as e:
            logger.error(f"Ошибка при обработке пополнения Steam: {e}")
            
            error_message = (
                f"❌ Произошла ошибка при обработке заказа.\n"
                f"Пожалуйста, свяжитесь с администратором.\n\n"
                f"Ошибка: {str(e)}"
            )
            
            if update.callback_query:
                await update.callback_query.edit_message_text(error_message)
            else:
                await update.message.reply_text(error_message)
EOL

# Создание основного файла бота
cat > $BOT_DIR/main.py << 'EOL'
#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import sys
import json
import logging
import importlib
import asyncio
import datetime
import traceback
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, ReplyKeyboardMarkup, KeyboardButton
from telegram.ext import Application, CommandHandler, MessageHandler, CallbackQueryHandler, ContextTypes, filters

# Импорт конфигурации
import config

# Настройка логирования
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO,
    handlers=[
        logging.FileHandler(os.path.join(config.LOGS_DIR, f"bot_{datetime.datetime.now().strftime('%Y%m%d')}.log"), encoding='utf-8'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# Импорт утилит
sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), "utils"))
from playerok_api import PlayerokAPI
from plugin_manager import PluginManager

class PlayerokBot:
    def __init__(self):
        """Инициализация бота"""
        self.plugin_manager = PluginManager()
        self.playerok_api = PlayerokAPI()
        self.accounts = {}
        self.active_tasks = {}
        self.load_accounts()
        
    async def start_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Обработчик команды /start"""
        user_id = update.effective_user.id
        
        # Проверка, является ли пользователь администратором
        if user_id not in config.ADMIN_IDS and not config.ADMIN_IDS:
            # Если список админов пуст, первый пользователь становится админом
            config.ADMIN_IDS.append(user_id)
            config.save_config()
            await update.message.reply_text("Вы были добавлены как первый администратор бота.")
        
        if user_id in config.ADMIN_IDS:
            # Создаем главное меню с кнопками
            keyboard = [
                [KeyboardButton("👤 Аккаунты"), KeyboardButton("🔌 Плагины")],
                [KeyboardButton("⚙️ Настройки"), KeyboardButton("📊 Статистика")],
                [KeyboardButton("🔄 Управление товарами"), KeyboardButton("❓ Помощь")]
            ]
            reply_markup = ReplyKeyboardMarkup(keyboard, resize_keyboard=True)
            
            await update.message.reply_text(
                f"👋 Добро пожаловать в бот для Playerok!\n\n"
                f"Используйте меню ниже для управления ботом:",
                reply_markup=reply_markup
            )
        else:
            await update.message.reply_text("У вас нет доступа к этому боту.")
    
    async def help_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Обработчик команды /help и кнопки Помощь"""
        help_text = (
            "🤖 *Помощь по использованию бота Playerok*\n\n"
            "*Основные функции:*\n\n"
            "👤 *Аккаунты* - Управление аккаунтами Playerok\n"
            "🔌 *Плагины* - Управление плагинами бота\n"
            "⚙️ *Настройки* - Настройка параметров бота\n"
            "📊 *Статистика* - Просмотр статистики по аккаунтам\n"
            "🔄 *Управление товарами* - Поднятие и восстановление товаров\n\n"
            "*Функции бота:*\n\n"
            "✅ Нечиталка чатов\n"
            "✅ Авто-поднятие товаров\n"
            "✅ Авто-восстановление товаров\n"
            "✅ Мульти-аккаунт с поддержкой прокси\n"
            "✅ Автоматические ответы\n"
            "✅ Уведомления о заказах\n"
            "✅ Автоматическое выполнение/возврат заказов\n"
            "✅ Поддержка плагинов\n\n"
            "Для начала работы добавьте аккаунт Playerok через меню 'Аккаунты'."
        )
        
        # Кнопка возврата в главное меню
        keyboard = [[InlineKeyboardButton("🔙 Назад", callback_data="back_to_main")]]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await update.message.reply_text(help_text, parse_mode='Markdown', reply_markup=reply_markup)
    
    async def status_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Обработчик команды /status"""
        user_id = update.effective_user.id
        if user_id not in config.ADMIN_IDS:
            await update.message.reply_text("У вас нет доступа к этой функции.")
            return
        
        # Сбор информации о статусе бота
        active_accounts = len(self.accounts)
        active_plugins = len(self.plugin_manager.get_active_plugins())
        active_tasks_count = len(self.active_tasks)
        
        status_text = (
            "📊 *Статус бота Playerok*\n\n"
            f"🟢 *Бот активен*\n"
            f"👤 Активных аккаунтов: {active_accounts}\n"
            f"🔌 Активных плагинов: {active_plugins}\n"
            f"⚙️ Активных задач: {active_tasks_count}\n\n"
            f"*Настройки:*\n"
            f"🔄 Автоподнятие: {'✅ Включено' if config.AUTO_BUMP_ENABLED else '❌ Выключено'}\n"
            f"🔄 Интервал автоподнятия: {config.AUTO_BUMP_INTERVAL // 60} мин\n"
            f"🔄 Автовосстановление: {'✅ Включено' if config.AUTO_RESTORE_ENABLED else '❌ Выключено'}\n"
            f"🔔 Уведомления: {'✅ Включено' if config.NOTIFICATIONS_ENABLED else '❌ Выключено'}\n"
            f"💬 Автоответ: {'✅ Включено' if config.AUTO_REPLY_ENABLED else '❌ Выключено'}\n"
        )
        
        # Кнопка возврата в главное меню
        keyboard = [[InlineKeyboardButton("🔙 Назад", callback_data="back_to_main")]]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await update.message.reply_text(status_text, parse_mode='Markdown', reply_markup=reply_markup)
    
    async def handle_accounts_menu(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Обработчик меню аккаунтов"""
        user_id = update.effective_user.id
        if user_id not in config.ADMIN_IDS:
            await update.message.reply_text("У вас нет доступа к этой функции.")
            return
        
        keyboard = [
            [InlineKeyboardButton("➕ Добавить аккаунт", callback_data="add_account")],
            [InlineKeyboardButton("🔍 Список аккаунтов", callback_data="list_accounts")],
            [InlineKeyboardButton("🔙 Назад в главное меню", callback_data="back_to_main")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        await update.message.reply_text("👤 *Управление аккаунтами Playerok*\n\nВыберите действие:", parse_mode='Markdown', reply_markup=reply_markup)
    
    async def handle_plugins_menu(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Обработчик меню плагинов"""
        user_id = update.effective_user.id
        if user_id not in config.ADMIN_IDS:
            await update.message.reply_text("У вас нет доступа к этой функции.")
            return
        
        plugins = self.plugin_manager.get_all_plugins()
        
        if not plugins:
            keyboard = [[InlineKeyboardButton("🔙 Назад в главное меню", callback_data="back_to_main")]]
            reply_markup = InlineKeyboardMarkup(keyboard)
            await update.message.reply_text(
                "🔌 *Плагины не найдены*\n\n"
                "Загрузите плагины в директорию plugins.",
                parse_mode='Markdown',
                reply_markup=reply_markup
            )
            return
        
        keyboard = []
        for plugin_name in plugins:
            is_active = plugin_name in self.plugin_manager.get_active_plugins()
            status = "✅" if is_active else "❌"
            keyboard.append([InlineKeyboardButton(f"{status} {plugin_name}", callback_data=f"toggle_plugin:{plugin_name}")])
        
        keyboard.append([InlineKeyboardButton("🔙 Назад в главное меню", callback_data="back_to_main")])
        reply_markup = InlineKeyboardMarkup(keyboard)
        await update.message.reply_text("🔌 *Управление плагинами*\n\nНажмите на плагин для включения/отключения:", parse_mode='Markdown', reply_markup=reply_markup)
    
    async def handle_settings_menu(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Обработчик меню настроек"""
        user_id = update.effective_user.id
        if user_id not in config.ADMIN_IDS:
            await update.message.reply_text("У вас нет доступа к этой функции.")
            return
        
        keyboard = [
            [InlineKeyboardButton(f"🔄 Автоподнятие: {'✅' if config.AUTO_BUMP_ENABLED else '❌'}", 
                                 callback_data="toggle_auto_bump")],
            [InlineKeyboardButton(f"⏱️ Интервал автоподнятия: {config.AUTO_BUMP_INTERVAL // 60} мин", 
                                 callback_data="set_bump_interval")],
            [InlineKeyboardButton(f"🔄 Автовосстановление: {'✅' if config.AUTO_RESTORE_ENABLED else '❌'}", 
                                 callback_data="toggle_auto_restore")],
            [InlineKeyboardButton(f"🔔 Уведомления: {'✅' if config.NOTIFICATIONS_ENABLED else '❌'}", 
                                 callback_data="toggle_notifications")],
            [InlineKeyboardButton(f"💬 Автоответ: {'✅' if config.AUTO_REPLY_ENABLED else '❌'}", 
                                 callback_data="toggle_auto_reply")],
            [InlineKeyboardButton("🔙 Назад в главное меню", callback_data="back_to_main")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        await update.message.reply_text("⚙️ *Настройки бота*\n\nНажмите на параметр для изменения:", parse_mode='Markdown', reply_markup=reply_markup)
    
    async def handle_stats_menu(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Обработчик меню статистики"""
        user_id = update.effective_user.id
        if user_id not in config.ADMIN_IDS:
            await update.message.reply_text("У вас нет доступа к этой функции.")
            return
        
        # Сбор статистики по аккаунтам
        stats_text = "📊 *Статистика аккаунтов*\n\n"
        
        if not self.accounts:
            stats_text += "Нет активных аккаунтов."
        else:
            for account_name, account_data in self.accounts.items():
                stats_text += f"*{account_name}*:\n"
                stats_text += f"- Активных товаров: {account_data.get('active_items', 0)}\n"
                stats_text += f"- Выполненных заказов: {account_data.get('completed_orders', 0)}\n"
                stats_text += f"- Возвращенных заказов: {account_data.get('returned_orders', 0)}\n"
                stats_text += f"- Доход: {account_data.get('income', 0)} руб.\n\n"
        
        keyboard = [[InlineKeyboardButton("🔙 Назад в главное меню", callback_data="back_to_main")]]
        reply_markup = InlineKeyboardMarkup(keyboard)
        await update.message.reply_text(stats_text, reply_markup=reply_markup, parse_mode='Markdown')
    
    async def handle_items_management_menu(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Обработчик меню управления товарами"""
        user_id = update.effective_user.id
        if user_id not in config.ADMIN_IDS:
            await update.message.reply_text("У вас нет доступа к этой функции.")
            return
        
        keyboard = [
            [InlineKeyboardButton("🔄 Поднять все товары", callback_data="bump_items")],
            [InlineKeyboardButton("🔄 Восстановить все товары", callback_data="restore_items")],
            [InlineKeyboardButton("🔙 Назад в главное меню", callback_data="back_to_main")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        await update.message.reply_text("🔄 *Управление товарами*\n\nВыберите действие:", parse_mode='Markdown', reply_markup=reply_markup)
    
    async def callback_handler(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Обработчик callback-запросов"""
        query = update.callback_query
        await query.answer()
        
        user_id = update.effective_user.id
        if user_id not in config.ADMIN_IDS:
            await query.edit_message_text("У вас нет доступа к этой функции.")
            return
        
        callback_data = query.data
        
        # Обработка различных callback-запросов
        if callback_data == "back_to_main":
            await query.delete_message()
            return
        elif callback_data == "add_account":
            await self.handle_add_account_callback(query)
        elif callback_data == "list_accounts":
            await self.handle_list_accounts_callback(query)
        elif callback_data.startswith("toggle_plugin:"):
            plugin_name = callback_data.split(":")[1]
            await self.handle_toggle_plugin_callback(query, plugin_name)
        elif callback_data == "toggle_auto_bump":
            await self.handle_toggle_auto_bump_callback(query)
        elif callback_data == "toggle_auto_restore":
            await self.handle_toggle_auto_restore_callback(query)
        elif callback_data == "toggle_notifications":
            await self.handle_toggle_notifications_callback(query)
        elif callback_data == "toggle_auto_reply":
            await self.handle_toggle_auto_reply_callback(query)
        elif callback_data == "set_bump_interval":
            await self.handle_set_bump_interval_callback(query)
        elif callback_data == "bump_items":
            await self.handle_bump_items_callback(query)
        elif callback_data == "restore_items":
            await self.handle_restore_items_callback(query)
        elif callback_data.startswith("remove_account:"):
            account_name = callback_data.split(":")[1]
            await self.handle_remove_account_callback(query, account_name)
        else:
            # Передаем обработку плагинам
            for plugin in self.plugin_manager.get_active_plugins().values():
                if hasattr(plugin, 'handle_callback') and await plugin.handle_callback(update, context, callback_data):
                    return
    
    async def handle_add_account_callback(self, query):
        """Обработчик callback для добавления аккаунта"""
        keyboard = [
            [InlineKeyboardButton("🔙 Назад", callback_data="back_to_accounts")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await query.edit_message_text(
            "➕ *Добавление аккаунта Playerok*\n\n"
            "Отправьте данные в формате:\n"
            "`логин пароль`\n\n"
            "Например: `mylogin mypassword`",
            parse_mode='Markdown',
            reply_markup=reply_markup
        )
        
        # Устанавливаем состояние ожидания ввода данных аккаунта
        context = query.bot.context
        context.user_data[query.from_user.id] = {"state": "waiting_account_data"}
    
    async def handle_list_accounts_callback(self, query):
        """Обработчик callback для списка аккаунтов"""
        if not self.accounts:
            keyboard = [[InlineKeyboardButton("🔙 Назад", callback_data="back_to_accounts")]]
            reply_markup = InlineKeyboardMarkup(keyboard)
            await query.edit_message_text("👤 *Список аккаунтов*\n\nНет добавленных аккаунтов.", parse_mode='Markdown', reply_markup=reply_markup)
            return
        
        accounts_text = "👤 *Список аккаунтов*\n\n"
        keyboard = []
        
        for account_name in self.accounts:
            accounts_text += f"- {account_name}\n"
            keyboard.append([InlineKeyboardButton(f"❌ Удалить {account_name}", callback_data=f"remove_account:{account_name}")])
        
        keyboard.append([InlineKeyboardButton("🔙 Назад", callback_data="back_to_accounts")])
        reply_markup = InlineKeyboardMarkup(keyboard)
        await query.edit_message_text(accounts_text, reply_markup=reply_markup, parse_mode='Markdown')
    
    async def handle_toggle_plugin_callback(self, query, plugin_name):
        """Обработчик callback для включения/выключения плагина"""
        if plugin_name in self.plugin_manager.get_active_plugins():
            self.plugin_manager.disable_plugin(plugin_name)
            status_text = f"❌ Плагин {plugin_name} отключен"
        else:
            success, error = self.plugin_manager.enable_plugin(plugin_name)
            if success:
                status_text = f"✅ Плагин {plugin_name} включен"
            else:
                status_text = f"❌ Ошибка при включении плагина {plugin_name}: {error}"
        
        # Обновляем список плагинов
        plugins = self.plugin_manager.get_all_plugins()
        keyboard = []
        
        for p_name in plugins:
            is_active = p_name in self.plugin_manager.get_active_plugins()
            status = "✅" if is_active else "❌"
            keyboard.append([InlineKeyboardButton(f"{status} {p_name}", callback_data=f"toggle_plugin:{p_name}")])
        
        keyboard.append([InlineKeyboardButton("🔙 Назад в главное меню", callback_data="back_to_main")])
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await query.edit_message_text(
            f"🔌 *Управление плагинами*\n\n{status_text}\n\nНажмите на плагин для включения/отключения:",
            parse_mode='Markdown',
            reply_markup=reply_markup
        )
    
    async def handle_toggle_auto_bump_callback(self, query):
        """Обработчик callback для включения/выключения автоподнятия"""
        config.AUTO_BUMP_ENABLED = not config.AUTO_BUMP_ENABLED
        config.save_config()
        
        # Обновляем меню настроек
        keyboard = [
            [InlineKeyboardButton(f"🔄 Автоподнятие: {'✅' if config.AUTO_BUMP_ENABLED else '❌'}", 
                                 callback_data="toggle_auto_bump")],
            [InlineKeyboardButton(f"⏱️ Интервал автоподнятия: {config.AUTO_BUMP_INTERVAL // 60} мин", 
                                 callback_data="set_bump_interval")],
            [InlineKeyboardButton(f"🔄 Автовосстановление: {'✅' if config.AUTO_RESTORE_ENABLED else '❌'}", 
                                 callback_data="toggle_auto_restore")],
            [InlineKeyboardButton(f"🔔 Уведомления: {'✅' if config.NOTIFICATIONS_ENABLED else '❌'}", 
                                 callback_data="toggle_notifications")],
            [InlineKeyboardButton(f"💬 Автоответ: {'✅' if config.AUTO_REPLY_ENABLED else '❌'}", 
                                 callback_data="toggle_auto_reply")],
            [InlineKeyboardButton("🔙 Назад в главное меню", callback_data="back_to_main")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        status = "включено" if config.AUTO_BUMP_ENABLED else "отключено"
        await query.edit_message_text(
            f"⚙️ *Настройки бота*\n\n✅ Автоподнятие {status}!\n\nНажмите на параметр для изменения:",
            parse_mode='Markdown',
            reply_markup=reply_markup
        )
    
    async def handle_toggle_auto_restore_callback(self, query):
        """Обработчик callback для включения/выключения автовосстановления"""
        config.AUTO_RESTORE_ENABLED = not config.AUTO_RESTORE_ENABLED
        config.save_config()
        
        # Обновляем меню настроек
        keyboard = [
            [InlineKeyboardButton(f"🔄 Автоподнятие: {'✅' if config.AUTO_BUMP_ENABLED else '❌'}", 
                                 callback_data="toggle_auto_bump")],
            [InlineKeyboardButton(f"⏱️ Интервал автоподнятия: {config.AUTO_BUMP_INTERVAL // 60} мин", 
                                 callback_data="set_bump_interval")],
            [InlineKeyboardButton(f"🔄 Автовосстановление: {'✅' if config.AUTO_RESTORE_ENABLED else '❌'}", 
                                 callback_data="toggle_auto_restore")],
            [InlineKeyboardButton(f"🔔 Уведомления: {'✅' if config.NOTIFICATIONS_ENABLED else '❌'}", 
                                 callback_data="toggle_notifications")],
            [InlineKeyboardButton(f"💬 Автоответ: {'✅' if config.AUTO_REPLY_ENABLED else '❌'}", 
                                 callback_data="toggle_auto_reply")],
            [InlineKeyboardButton("🔙 Назад в главное меню", callback_data="back_to_main")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        status = "включено" if config.AUTO_RESTORE_ENABLED else "отключено"
        await query.edit_message_text(
            f"⚙️ *Настройки бота*\n\n✅ Автовосстановление {status}!\n\nНажмите на параметр для изменения:",
            parse_mode='Markdown',
            reply_markup=reply_markup
        )
    
    async def handle_toggle_notifications_callback(self, query):
        """Обработчик callback для включения/выключения уведомлений"""
        config.NOTIFICATIONS_ENABLED = not config.NOTIFICATIONS_ENABLED
        config.save_config()
        
        # Обновляем меню настроек
        keyboard = [
            [InlineKeyboardButton(f"🔄 Автоподнятие: {'✅' if config.AUTO_BUMP_ENABLED else '❌'}", 
                                 callback_data="toggle_auto_bump")],
            [InlineKeyboardButton(f"⏱️ Интервал автоподнятия: {config.AUTO_BUMP_INTERVAL // 60} мин", 
                                 callback_data="set_bump_interval")],
            [InlineKeyboardButton(f"🔄 Автовосстановление: {'✅' if config.AUTO_RESTORE_ENABLED else '❌'}", 
                                 callback_data="toggle_auto_restore")],
            [InlineKeyboardButton(f"🔔 Уведомления: {'✅' if config.NOTIFICATIONS_ENABLED else '❌'}", 
                                 callback_data="toggle_notifications")],
            [InlineKeyboardButton(f"💬 Автоответ: {'✅' if config.AUTO_REPLY_ENABLED else '❌'}", 
                                 callback_data="toggle_auto_reply")],
            [InlineKeyboardButton("🔙 Назад в главное меню", callback_data="back_to_main")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        status = "включены" if config.NOTIFICATIONS_ENABLED else "отключены"
        await query.edit_message_text(
            f"⚙️ *Настройки бота*\n\n✅ Уведомления {status}!\n\nНажмите на параметр для изменения:",
            parse_mode='Markdown',
            reply_markup=reply_markup
        )
    
    async def handle_toggle_auto_reply_callback(self, query):
        """Обработчик callback для включения/выключения автоответа"""
        config.AUTO_REPLY_ENABLED = not config.AUTO_REPLY_ENABLED
        config.save_config()
        
        # Обновляем меню настроек
        keyboard = [
            [InlineKeyboardButton(f"🔄 Автоподнятие: {'✅' if config.AUTO_BUMP_ENABLED else '❌'}", 
                                 callback_data="toggle_auto_bump")],
            [InlineKeyboardButton(f"⏱️ Интервал автоподнятия: {config.AUTO_BUMP_INTERVAL // 60} мин", 
                                 callback_data="set_bump_interval")],
            [InlineKeyboardButton(f"🔄 Автовосстановление: {'✅' if config.AUTO_RESTORE_ENABLED else '❌'}", 
                                 callback_data="toggle_auto_restore")],
            [InlineKeyboardButton(f"🔔 Уведомления: {'✅' if config.NOTIFICATIONS_ENABLED else '❌'}", 
                                 callback_data="toggle_notifications")],
            [InlineKeyboardButton(f"💬 Автоответ: {'✅' if config.AUTO_REPLY_ENABLED else '❌'}", 
                                 callback_data="toggle_auto_reply")],
            [InlineKeyboardButton("🔙 Назад в главное меню", callback_data="back_to_main")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        status = "включен" if config.AUTO_REPLY_ENABLED else "отключен"
        await query.edit_message_text(
            f"⚙️ *Настройки бота*\n\n✅ Автоответ {status}!\n\nНажмите на параметр для изменения:",
            parse_mode='Markdown',
            reply_markup=reply_markup
        )
    
    async def handle_set_bump_interval_callback(self, query):
        """Обработчик callback для установки интервала автоподнятия"""
        keyboard = [
            [
                InlineKeyboardButton("30 мин", callback_data="set_interval:30"),
                InlineKeyboardButton("1 час", callback_data="set_interval:60"),
                InlineKeyboardButton("2 часа", callback_data="set_interval:120")
            ],
            [
                InlineKeyboardButton("3 часа", callback_data="set_interval:180"),
                InlineKeyboardButton("6 часов", callback_data="set_interval:360"),
                InlineKeyboardButton("12 часов", callback_data="set_interval:720")
            ],
            [InlineKeyboardButton("🔙 Назад", callback_data="back_to_settings")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await query.edit_message_text(
            "⏱️ *Установка интервала автоподнятия*\n\n"
            f"Текущий интервал: {config.AUTO_BUMP_INTERVAL // 60} мин\n\n"
            "Выберите новый интервал:",
            parse_mode='Markdown',
            reply_markup=reply_markup
        )
    
    async def handle_bump_items_callback(self, query):
        """Обработчик callback для поднятия товаров"""
        if not self.accounts:
            keyboard = [[InlineKeyboardButton("🔙 Назад", callback_data="back_to_items_management")]]
            reply_markup = InlineKeyboardMarkup(keyboard)
            await query.edit_message_text(
                "🔄 *Поднятие товаров*\n\n"
                "Нет добавленных аккаунтов.",
                parse_mode='Markdown',
                reply_markup=reply_markup
            )
            return
        
        await query.edit_message_text("🔄 *Начинаю поднятие товаров...*", parse_mode='Markdown')
        
        results = []
        for username, account_data in self.accounts.items():
            try:
                success, result = await self.playerok_api.bump_items(username, account_data["password"])
                if success:
                    results.append(f"✅ {username}: {result}")
                else:
                    results.append(f"❌ {username}: {result}")
            except Exception as e:
                results.append(f"❌ {username}: Ошибка - {str(e)}")
        
        keyboard = [[InlineKeyboardButton("🔙 Назад", callback_data="back_to_items_management")]]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await query.edit_message_text(
            "🔄 *Результаты поднятия товаров*\n\n" + "\n".join(results),
            parse_mode='Markdown',
            reply_markup=reply_markup
        )
    
    async def handle_restore_items_callback(self, query):
        """Обработчик callback для восстановления товаров"""
        if not self.accounts:
            keyboard = [[InlineKeyboardButton("🔙 Назад", callback_data="back_to_items_management")]]
            reply_markup = InlineKeyboardMarkup(keyboard)
            await query.edit_message_text(
                "🔄 *Восстановление товаров*\n\n"
                "Нет добавленных аккаунтов.",
                parse_mode='Markdown',
                reply_markup=reply_markup
            )
            return
        
        await query.edit_message_text("🔄 *Начинаю восстановление товаров...*", parse_mode='Markdown')
        
        results = []
        for username, account_data in self.accounts.items():
            try:
                success, result = await self.playerok_api.restore_items(username, account_data["password"])
                if success:
                    results.append(f"✅ {username}: {result}")
                else:
                    results.append(f"❌ {username}: {result}")
            except Exception as e:
                results.append(f"❌ {username}: Ошибка - {str(e)}")
        
        keyboard = [[InlineKeyboardButton("🔙 Назад", callback_data="back_to_items_management")]]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await query.edit_message_text(
            "🔄 *Результаты восстановления товаров*\n\n" + "\n".join(results),
            parse_mode='Markdown',
            reply_markup=reply_markup
        )
    
    async def handle_remove_account_callback(self, query, account_name):
        """Обработчик callback для удаления аккаунта"""
        if account_name in self.accounts:
            del self.accounts[account_name]
            self.save_accounts()
            
            # Обновляем список аккаунтов
            if not self.accounts:
                keyboard = [[InlineKeyboardButton("🔙 Назад", callback_data="back_to_accounts")]]
                reply_markup = InlineKeyboardMarkup(keyboard)
                await query.edit_message_text(
                    f"👤 *Список аккаунтов*\n\n✅ Аккаунт {account_name} удален!\n\nНет добавленных аккаунтов.",
                    parse_mode='Markdown',
                    reply_markup=reply_markup
                )
                return
            
            accounts_text = f"👤 *Список аккаунтов*\n\n✅ Аккаунт {account_name} удален!\n\n"
            keyboard = []
            
            for acc_name in self.accounts:
                accounts_text += f"- {acc_name}\n"
                keyboard.append([InlineKeyboardButton(f"❌ Удалить {acc_name}", callback_data=f"remove_account:{acc_name}")])
            
            keyboard.append([InlineKeyboardButton("🔙 Назад", callback_data="back_to_accounts")])
            reply_markup = InlineKeyboardMarkup(keyboard)
            await query.edit_message_text(accounts_text, reply_markup=reply_markup, parse_mode='Markdown')
        else:
            keyboard = [[InlineKeyboardButton("🔙 Назад", callback_data="back_to_accounts")]]
            reply_markup = InlineKeyboardMarkup(keyboard)
            await query.edit_message_text(
                f"👤 *Список аккаунтов*\n\n❌ Аккаунт {account_name} не найден!",
                parse_mode='Markdown',
                reply_markup=reply_markup
            )
    
    async def message_handler(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Обработчик всех сообщений"""
        # Проверка на сообщения из меню
        if update.effective_chat.type == "private":
            message_text = update.message.text
            
            # Обработка сообщений из главного меню
            if message_text == "👤 Аккаунты":
                await self.handle_accounts_menu(update, context)
            elif message_text == "🔌 Плагины":
                await self.handle_plugins_menu(update, context)
            elif message_text == "⚙️ Настройки":
                await self.handle_settings_menu(update, context)
            elif message_text == "📊 Статистика":
                await self.handle_stats_menu(update, context)
            elif message_text == "🔄 Управление товарами":
                await self.handle_items_management_menu(update, context)
            elif message_text == "❓ Помощь":
                await self.help_command(update, context)
            # Обработка ввода данных аккаунта
            elif "state" in context.user_data.get(update.effective_user.id, {}) and context.user_data[update.effective_user.id]["state"] == "waiting_account_data":
                await self.handle_account_data_input(update, context)
            # Обработка ввода интервала автоподнятия
            elif "state" in context.user_data.get(update.effective_user.id, {}) and context.user_data[update.effective_user.id]["state"] == "waiting_interval":
                await self.handle_interval_input(update, context)
            # Проверка на сообщения от Playerok
            elif config.AUTO_REPLY_ENABLED:
                # Передаем обработку плагинам
                for plugin in self.plugin_manager.get_active_plugins().values():
                    if hasattr(plugin, 'handle_message') and await plugin.handle_message(update, context):
                        return
                
                # Обработка сообщений от Playerok
                if "заказ был выполнен" in message_text.lower():
                    await update.message.reply_text("Спасибо за заказ! Буду рад видеть вас снова! ❤️")
                elif "проблема с заказом" in message_text.lower():
                    await update.message.reply_text("Извините за неудобства. Пожалуйста, опишите проблему подробнее, и я постараюсь помочь.")
    
    async def handle_account_data_input(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Обработчик ввода данных аккаунта"""
        user_id = update.effective_user.id
        if user_id not in config.ADMIN_IDS:
            await update.message.reply_text("У вас нет доступа к этой функции.")
            return
        
        # Сбрасываем состояние
        context.user_data[user_id]["state"] = None
        
        message_text = update.message.text
        parts = message_text.split()
        
        if len(parts) < 2:
            await update.message.reply_text(
                "❌ *Неверный формат данных*\n\n"
                "Необходимо указать логин и пароль через пробел.\n"
                "Например: `mylogin mypassword`",
                parse_mode='Markdown'
            )
            return
        
        username = parts[0]
        password = parts[1]
        
        # Проверка подключения к аккаунту
        message = await update.message.reply_text("🔄 *Проверка подключения к аккаунту...*", parse_mode='Markdown')
        
        success, result = await self.playerok_api.login(username, password)
        
        if success:
            # Сохранение аккаунта
            self.accounts[username] = {
                "password": password,
                "active_items": 0,
                "completed_orders": 0,
                "returned_orders": 0,
                "income": 0
            }
            self.save_accounts()
            
            await message.edit_text(f"✅ *Аккаунт {username} успешно добавлен!*", parse_mode='Markdown')
        else:
            await message.edit_text(f"❌ *Ошибка при добавлении аккаунта:* {result}", parse_mode='Markdown')
    
    async def handle_interval_input(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Обработчик ввода интервала автоподнятия"""
        user_id = update.effective_user.id
        if user_id not in config.ADMIN_IDS:
            await update.message.reply_text("У вас нет доступа к этой функции.")
            return
        
        # Сбрасываем состояние
        context.user_data[user_id]["state"] = None
        
        message_text = update.message.text
        
        if not message_text.isdigit():
            await update.message.reply_text(
                "❌ *Неверный формат интервала*\n\n"
                "Интервал должен быть числом (в минутах).",
                parse_mode='Markdown'
            )
            return
        
        interval_minutes = int(message_text)
        if interval_minutes < 5:
            await update.message.reply_text(
                "❌ *Слишком маленький интервал*\n\n"
                "Минимальный интервал - 5 минут.",
                parse_mode='Markdown'
            )
            return
        
        config.AUTO_BUMP_INTERVAL = interval_minutes * 60
        config.save_config()
        await update.message.reply_text(f"✅ *Интервал автоподнятия установлен на {interval_minutes} минут.*", parse_mode='Markdown')
    
    async def auto_bump_task(self):
        """Задача для автоматического поднятия товаров"""
        while True:
            if config.AUTO_BUMP_ENABLED and self.accounts:
                logger.info("Запуск автоматического поднятия товаров")
                
                for username, account_data in self.accounts.items():
                    try:
                        success, result = await self.playerok_api.bump_items(username, account_data["password"])
                        if success:
                            logger.info(f"Автоподнятие для {username}: {result}")
                            if config.NOTIFICATIONS_ENABLED:
                                for admin_id in config.ADMIN_IDS:
                                    try:
                                        await self.application.bot.send_message(
                                            chat_id=admin_id,
                                            text=f"🔄 Автоподнятие для {username}: {result}"
                                        )
                                    except Exception as e:
                                        logger.error(f"Ошибка отправки уведомления: {e}")
                        else:
                            logger.error(f"Ошибка автоподнятия для {username}: {result}")
                            if config.NOTIFICATIONS_ENABLED:
                                for admin_id in config.ADMIN_IDS:
                                    try:
                                        await self.application.bot.send_message(
                                            chat_id=admin_id,
                                            text=f"❌ Ошибка автоподнятия для {username}: {result}"
                                        )
                                    except Exception as e:
                                        logger.error(f"Ошибка отправки уведомления: {e}")
                    except Exception as e:
                        logger.error(f"Исключение при автоподнятии для {username}: {e}")
            
            # Ждем до следующего запуска
            await asyncio.sleep(config.AUTO_BUMP_INTERVAL)
    
    async def auto_restore_task(self):
        """Задача для автоматического восстановления товаров"""
        while True:
            if config.AUTO_RESTORE_ENABLED and self.accounts:
                logger.info("Запуск автоматического восстановления товаров")
                
                for username, account_data in self.accounts.items():
                    try:
                        success, result = await self.playerok_api.restore_items(username, account_data["password"])
                        if success:
                            logger.info(f"Автовосстановление для {username}: {result}")
                            if config.NOTIFICATIONS_ENABLED:
                                for admin_id in config.ADMIN_IDS:
                                    try:
                                        await self.application.bot.send_message(
                                            chat_id=admin_id,
                                            text=f"🔄 Автовосстановление для {username}: {result}"
                                        )
                                    except Exception as e:
                                        logger.error(f"Ошибка отправки уведомления: {e}")
                        else:
                            logger.error(f"Ошибка автовосстановления для {username}: {result}")
                            if config.NOTIFICATIONS_ENABLED:
                                for admin_id in config.ADMIN_IDS:
                                    try:
                                        await self.application.bot.send_message(
                                            chat_id=admin_id,
                                            text=f"❌ Ошибка автовосстановления для {username}: {result}"
                                        )
                                    except Exception as e:
                                        logger.error(f"Ошибка отправки уведомления: {e}")
                    except Exception as e:
                        logger.error(f"Исключение при автовосстановлении для {username}: {e}")
            
            # Ждем до следующего запуска
            await asyncio.sleep(config.AUTO_RESTORE_INTERVAL)
    
    def load_accounts(self):
        """Загрузка аккаунтов из файла"""
        accounts_file = os.path.join(config.DATA_DIR, "accounts.json")
        if os.path.exists(accounts_file):
            try:
                with open(accounts_file, "r", encoding="utf-8") as f:
                    self.accounts = json.load(f)
                logger.info(f"Загружено {len(self.accounts)} аккаунтов")
            except Exception as e:
                logger.error(f"Ошибка загрузки аккаунтов: {e}")
                self.accounts = {}
    
    def save_accounts(self):
        """Сохранение аккаунтов в файл"""
        accounts_file = os.path.join(config.DATA_DIR, "accounts.json")
        try:
            with open(accounts_file, "w", encoding="utf-8") as f:
                json.dump(self.accounts, f, indent=4, ensure_ascii=False)
            logger.info(f"Сохранено {len(self.accounts)} аккаунтов")
        except Exception as e:
            logger.error(f"Ошибка сохранения аккаунтов: {e}")
    
    async def run(self):
        """Запуск бота"""
        # Создание и настройка приложения
        self.application = Application.builder().token(config.BOT_TOKEN).build()
        
        # Регистрация обработчиков команд
        self.application.add_handler(CommandHandler("start", self.start_command))
        self.application.add_handler(CommandHandler("help", self.help_command))
        self.application.add_handler(CommandHandler("status", self.status_command))
        
        # Регистрация обработчика callback-запросов
        self.application.add_handler(CallbackQueryHandler(self.callback_handler))
        
        # Регистрация обработчика сообщений
        self.application.add_handler(MessageHandler(filters.TEXT, self.message_handler))
        
        # Загрузка плагинов
        self.plugin_manager.load_plugins()
        
        # Запуск фоновых задач
        asyncio.create_task(self.auto_bump_task())
        asyncio.create_task(self.auto_restore_task())
        
        # Запуск бота
        await self.application.initialize()
        await self.application.start()
        await self.application.updater.start_polling()
        
        logger.info("Бот запущен")
        
        # Ожидание завершения работы бота
        await self.application.updater.stop()
        await self.application.stop()
        await self.application.shutdown()

if __name__ == "__main__":
    try:
        # Создание и запуск бота
        bot = PlayerokBot()
        asyncio.run(bot.run())
    except Exception as e:
        logger.error(f"Критическая ошибка: {e}")
        logger.error(traceback.format_exc())
EOL

# Создание файла запуска бота
cat > $BOT_DIR/run_bot.sh << 'EOL'
#!/bin/bash
cd "$(dirname "$0")"
python main.py
EOL

# Делаем скрипт запуска исполняемым
chmod +x $BOT_DIR/run_bot.sh

# Создание файла README.md с инструкциями
cat > $BOT_DIR/README.md << 'EOL'
# Telegram бот для Playerok

## Описание
Этот бот предназначен для автоматизации работы с площадкой Playerok. Он поддерживает множество функций, включая автоподнятие товаров, автовосстановление, мульти-аккаунт, плагины и многое другое.

## Функции
- ✅ Нечиталка чатов
- ✅ Авто-поднятие товаров
- ✅ Авто-восстановление товаров
- ✅ Мульти-аккаунт с поддержкой прокси
- ✅ Автоматические ответы
- ✅ Уведомления о заказах
- ✅ Автоматическое выполнение/возврат заказов
- ✅ Поддержка плагинов
- ✅ Подробная статистика по каждому аккаунту
- ✅ Гибкая настройка параметров

## Установка и запуск

### Первый запуск
1. Откройте Termux
2. Выполните команду:
```
bash run_bot.sh
```

3. После запуска бота, отправьте команду `/start` в чате с ботом
4. Введите токен бота, когда будет предложено
5. Добавьте аккаунты Playerok через меню "Аккаунты"

### Настройка токена бота
Перед использованием бота необходимо указать токен вашего Telegram бота. Для этого:
1. Откройте файл `config.py`
2. Найдите строку `BOT_TOKEN = "YOUR_BOT_TOKEN"`
3. Замените `YOUR_BOT_TOKEN` на ваш токен бота

### Плагины
Бот поддерживает плагины. Плагины должны быть размещены в директории `plugins`. 
По умолчанию установлен плагин для автоматического пополнения баланса Steam.

## Управление ботом
Управление ботом осуществляется через меню с кнопками:
- 👤 **Аккаунты** - Управление аккаунтами Playerok
- 🔌 **Плагины** - Управление плагинами бота
- ⚙️ **Настройки** - Настройка параметров бота
- 📊 **Статистика** - Просмотр статистики по аккаунтам
- 🔄 **Управление товарами** - Поднятие и восстановление товаров
- ❓ **Помощь** - Справка по использованию бота

## Поддержка
По всем вопросам обращайтесь к разработчику.
EOL

# Создание файла для запуска установки
cat > $BOT_DIR/setup_token.sh << 'EOL'
#!/bin/bash
# Скрипт для настройки токена бота

# Цвета для вывода
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

echo -e "${GREEN}=== Настройка токена Telegram бота ===${NC}"
echo -e "${YELLOW}Этот скрипт поможет вам настроить токен вашего Telegram бота${NC}"

# Запрос токена бота
echo -e "\n${GREEN}Введите токен вашего Telegram бота:${NC}"
read -p "> " BOT_TOKEN

if [ -z "$BOT_TOKEN" ]; then
    echo -e "${RED}Ошибка: Токен не может быть пустым${NC}"
    exit 1
fi

# Обновление файла конфигурации
CONFIG_FILE="config.py"
if [ -f "$CONFIG_FILE" ]; then
    # Заменяем строку с токеном
    sed -i "s/BOT_TOKEN = \".*\"/BOT_TOKEN = \"$BOT_TOKEN\"/" "$CONFIG_FILE"
    echo -e "${GREEN}Токен бота успешно обновлен!${NC}"
else
    echo -e "${RED}Ошибка: Файл конфигурации не найден${NC}"
    exit 1
fi

echo -e "\n${GREEN}Теперь вы можете запустить бота командой:${NC}"
echo -e "${YELLOW}./run_bot.sh${NC}"
EOL

# Делаем скрипт настройки токена исполняемым
chmod +x $BOT_DIR/setup_token.sh

# Завершение установки
echo -e "\n${GREEN}[5/5] Установка завершена!${NC}"
echo -e "${YELLOW}Бот установлен в директорию: $BOT_DIR${NC}"
echo -e "${YELLOW}Для настройки токена бота выполните:${NC}"
echo -e "${GREEN}cd $BOT_DIR && ./setup_token.sh${NC}"
echo -e "${YELLOW}Для запуска бота выполните:${NC}"
echo -e "${GREEN}cd $BOT_DIR && ./run_bot.sh${NC}"
EOL

# Делаем скрипт установки исполняемым
chmod +x /home/ubuntu/telegram_bot_playerok/install.sh
