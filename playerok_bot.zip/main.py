#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import sys
import json
import logging
import importlib
import asyncio
import datetime
import traceback
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, ReplyKeyboardMarkup, KeyboardButton
from telegram.ext import Application, CommandHandler, MessageHandler, CallbackQueryHandler, ContextTypes, filters

# Импорт конфигурации
import config

# Настройка логирования
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO,
    handlers=[
        logging.FileHandler(os.path.join(config.LOGS_DIR, f"bot_{datetime.datetime.now().strftime('%Y%m%d')}.log"), encoding='utf-8'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# Импорт утилит
sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), "utils"))
from playerok_api import PlayerokAPI
from plugin_manager import PluginManager

class PlayerokBot:
    def __init__(self):
        """Инициализация бота"""
        self.plugin_manager = PluginManager()
        self.playerok_api = PlayerokAPI()
        self.accounts = {}
        self.active_tasks = {}
        self.load_accounts()
        
    async def start_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Обработчик команды /start"""
        user_id = update.effective_user.id
        
        # Проверка, является ли пользователь администратором
        if user_id not in config.ADMIN_IDS and not config.ADMIN_IDS:
            # Если список админов пуст, первый пользователь становится админом
            config.ADMIN_IDS.append(user_id)
            config.save_config()
            await update.message.reply_text("Вы были добавлены как первый администратор бота.")
        
        if user_id in config.ADMIN_IDS:
            # Создаем главное меню с кнопками
            keyboard = [
                [KeyboardButton("👤 Аккаунты"), KeyboardButton("🔌 Плагины")],
                [KeyboardButton("⚙️ Настройки"), KeyboardButton("📊 Статистика")],
                [KeyboardButton("🔄 Управление товарами"), KeyboardButton("❓ Помощь")]
            ]
            reply_markup = ReplyKeyboardMarkup(keyboard, resize_keyboard=True)
            
            await update.message.reply_text(
                f"👋 Добро пожаловать в бот для Playerok!\n\n"
                f"Используйте меню ниже для управления ботом:",
                reply_markup=reply_markup
            )
        else:
            await update.message.reply_text("У вас нет доступа к этому боту.")
    
    async def help_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Обработчик команды /help и кнопки Помощь"""
        help_text = (
            "🤖 *Помощь по использованию бота Playerok*\n\n"
            "*Основные функции:*\n\n"
            "👤 *Аккаунты* - Управление аккаунтами Playerok\n"
            "🔌 *Плагины* - Управление плагинами бота\n"
            "⚙️ *Настройки* - Настройка параметров бота\n"
            "📊 *Статистика* - Просмотр статистики по аккаунтам\n"
            "🔄 *Управление товарами* - Поднятие и восстановление товаров\n\n"
            "*Функции бота:*\n\n"
            "✅ Нечиталка чатов\n"
            "✅ Авто-поднятие товаров\n"
            "✅ Авто-восстановление товаров\n"
            "✅ Мульти-аккаунт с поддержкой прокси\n"
            "✅ Автоматические ответы\n"
            "✅ Уведомления о заказах\n"
            "✅ Автоматическое выполнение/возврат заказов\n"
            "✅ Поддержка плагинов\n\n"
            "Для начала работы добавьте аккаунт Playerok через меню 'Аккаунты'."
        )
        
        # Кнопка возврата в главное меню
        keyboard = [[InlineKeyboardButton("🔙 Назад", callback_data="back_to_main")]]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await update.message.reply_text(help_text, parse_mode='Markdown', reply_markup=reply_markup)
    
    async def status_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Обработчик команды /status"""
        user_id = update.effective_user.id
        if user_id not in config.ADMIN_IDS:
            await update.message.reply_text("У вас нет доступа к этой функции.")
            return
        
        # Сбор информации о статусе бота
        active_accounts = len(self.accounts)
        active_plugins = len(self.plugin_manager.get_active_plugins())
        active_tasks_count = len(self.active_tasks)
        
        status_text = (
            "📊 *Статус бота Playerok*\n\n"
            f"🟢 *Бот активен*\n"
            f"👤 Активных аккаунтов: {active_accounts}\n"
            f"🔌 Активных плагинов: {active_plugins}\n"
            f"⚙️ Активных задач: {active_tasks_count}\n\n"
            f"*Настройки:*\n"
            f"🔄 Автоподнятие: {'✅ Включено' if config.AUTO_BUMP_ENABLED else '❌ Выключено'}\n"
            f"🔄 Интервал автоподнятия: {config.AUTO_BUMP_INTERVAL // 60} мин\n"
            f"🔄 Автовосстановление: {'✅ Включено' if config.AUTO_RESTORE_ENABLED else '❌ Выключено'}\n"
            f"🔔 Уведомления: {'✅ Включено' if config.NOTIFICATIONS_ENABLED else '❌ Выключено'}\n"
            f"💬 Автоответ: {'✅ Включено' if config.AUTO_REPLY_ENABLED else '❌ Выключено'}\n"
        )
        
        # Кнопка возврата в главное меню
        keyboard = [[InlineKeyboardButton("🔙 Назад", callback_data="back_to_main")]]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await update.message.reply_text(status_text, parse_mode='Markdown', reply_markup=reply_markup)
    
    async def handle_accounts_menu(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Обработчик меню аккаунтов"""
        user_id = update.effective_user.id
        if user_id not in config.ADMIN_IDS:
            await update.message.reply_text("У вас нет доступа к этой функции.")
            return
        
        keyboard = [
            [InlineKeyboardButton("➕ Добавить аккаунт", callback_data="add_account")],
            [InlineKeyboardButton("🔍 Список аккаунтов", callback_data="list_accounts")],
            [InlineKeyboardButton("🔙 Назад в главное меню", callback_data="back_to_main")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        await update.message.reply_text("👤 *Управление аккаунтами Playerok*\n\nВыберите действие:", parse_mode='Markdown', reply_markup=reply_markup)
    
    async def handle_plugins_menu(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Обработчик меню плагинов"""
        user_id = update.effective_user.id
        if user_id not in config.ADMIN_IDS:
            await update.message.reply_text("У вас нет доступа к этой функции.")
            return
        
        plugins = self.plugin_manager.get_all_plugins()
        
        if not plugins:
            keyboard = [[InlineKeyboardButton("🔙 Назад в главное меню", callback_data="back_to_main")]]
            reply_markup = InlineKeyboardMarkup(keyboard)
            await update.message.reply_text(
                "🔌 *Плагины не найдены*\n\n"
                "Загрузите плагины в директорию plugins.",
                parse_mode='Markdown',
                reply_markup=reply_markup
            )
            return
        
        keyboard = []
        for plugin_name in plugins:
            is_active = plugin_name in self.plugin_manager.get_active_plugins()
            status = "✅" if is_active else "❌"
            keyboard.append([InlineKeyboardButton(f"{status} {plugin_name}", callback_data=f"toggle_plugin:{plugin_name}")])
        
        keyboard.append([InlineKeyboardButton("🔙 Назад в главное меню", callback_data="back_to_main")])
        reply_markup = InlineKeyboardMarkup(keyboard)
        await update.message.reply_text("🔌 *Управление плагинами*\n\nНажмите на плагин для включения/отключения:", parse_mode='Markdown', reply_markup=reply_markup)
    
    async def handle_settings_menu(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Обработчик меню настроек"""
        user_id = update.effective_user.id
        if user_id not in config.ADMIN_IDS:
            await update.message.reply_text("У вас нет доступа к этой функции.")
            return
        
        keyboard = [
            [InlineKeyboardButton(f"🔄 Автоподнятие: {'✅' if config.AUTO_BUMP_ENABLED else '❌'}", 
                                 callback_data="toggle_auto_bump")],
            [InlineKeyboardButton(f"⏱️ Интервал автоподнятия: {config.AUTO_BUMP_INTERVAL // 60} мин", 
                                 callback_data="set_bump_interval")],
            [InlineKeyboardButton(f"🔄 Автовосстановление: {'✅' if config.AUTO_RESTORE_ENABLED else '❌'}", 
                                 callback_data="toggle_auto_restore")],
            [InlineKeyboardButton(f"🔔 Уведомления: {'✅' if config.NOTIFICATIONS_ENABLED else '❌'}", 
                                 callback_data="toggle_notifications")],
            [InlineKeyboardButton(f"💬 Автоответ: {'✅' if config.AUTO_REPLY_ENABLED else '❌'}", 
                                 callback_data="toggle_auto_reply")],
            [InlineKeyboardButton("🔙 Назад в главное меню", callback_data="back_to_main")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        await update.message.reply_text("⚙️ *Настройки бота*\n\nНажмите на параметр для изменения:", parse_mode='Markdown', reply_markup=reply_markup)
    
    async def handle_stats_menu(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Обработчик меню статистики"""
        user_id = update.effective_user.id
        if user_id not in config.ADMIN_IDS:
            await update.message.reply_text("У вас нет доступа к этой функции.")
            return
        
        # Сбор статистики по аккаунтам
        stats_text = "📊 *Статистика аккаунтов*\n\n"
        
        if not self.accounts:
            stats_text += "Нет активных аккаунтов."
        else:
            for account_name, account_data in self.accounts.items():
                stats_text += f"*{account_name}*:\n"
                stats_text += f"- Активных товаров: {account_data.get('active_items', 0)}\n"
                stats_text += f"- Выполненных заказов: {account_data.get('completed_orders', 0)}\n"
                stats_text += f"- Возвращенных заказов: {account_data.get('returned_orders', 0)}\n"
                stats_text += f"- Доход: {account_data.get('income', 0)} руб.\n\n"
        
        keyboard = [[InlineKeyboardButton("🔙 Назад в главное меню", callback_data="back_to_main")]]
        reply_markup = InlineKeyboardMarkup(keyboard)
        await update.message.reply_text(stats_text, reply_markup=reply_markup, parse_mode='Markdown')
    
    async def handle_items_management_menu(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Обработчик меню управления товарами"""
        user_id = update.effective_user.id
        if user_id not in config.ADMIN_IDS:
            await update.message.reply_text("У вас нет доступа к этой функции.")
            return
        
        keyboard = [
            [InlineKeyboardButton("🔄 Поднять все товары", callback_data="bump_items")],
            [InlineKeyboardButton("🔄 Восстановить все товары", callback_data="restore_items")],
            [InlineKeyboardButton("🔙 Назад в главное меню", callback_data="back_to_main")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        await update.message.reply_text("🔄 *Управление товарами*\n\nВыберите действие:", parse_mode='Markdown', reply_markup=reply_markup)
    
    async def callback_handler(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Обработчик callback-запросов"""
        query = update.callback_query
        await query.answer()
        
        user_id = update.effective_user.id
        if user_id not in config.ADMIN_IDS:
            await query.edit_message_text("У вас нет доступа к этой функции.")
            return
        
        callback_data = query.data
        
        # Обработка различных callback-запросов
        if callback_data == "back_to_main":
            await query.delete_message()
            return
        elif callback_data == "add_account":
            await self.handle_add_account_callback(query)
        elif callback_data == "list_accounts":
            await self.handle_list_accounts_callback(query)
        elif callback_data.startswith("toggle_plugin:"):
            plugin_name = callback_data.split(":")[1]
            await self.handle_toggle_plugin_callback(query, plugin_name)
        elif callback_data == "toggle_auto_bump":
            await self.handle_toggle_auto_bump_callback(query)
        elif callback_data == "toggle_auto_restore":
            await self.handle_toggle_auto_restore_callback(query)
        elif callback_data == "toggle_notifications":
            await self.handle_toggle_notifications_callback(query)
        elif callback_data == "toggle_auto_reply":
            await self.handle_toggle_auto_reply_callback(query)
        elif callback_data == "set_bump_interval":
            await self.handle_set_bump_interval_callback(query)
        elif callback_data == "bump_items":
            await self.handle_bump_items_callback(query)
        elif callback_data == "restore_items":
            await self.handle_restore_items_callback(query)
        elif callback_data.startswith("remove_account:"):
            account_name = callback_data.split(":")[1]
            await self.handle_remove_account_callback(query, account_name)
        else:
            # Передаем обработку плагинам
            for plugin in self.plugin_manager.get_active_plugins().values():
                if hasattr(plugin, 'handle_callback') and await plugin.handle_callback(update, context, callback_data):
                    return
    
    async def handle_add_account_callback(self, query):
        """Обработчик callback для добавления аккаунта"""
        keyboard = [
            [InlineKeyboardButton("🔙 Назад", callback_data="back_to_accounts")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await query.edit_message_text(
            "➕ *Добавление аккаунта Playerok*\n\n"
            "Отправьте данные в формате:\n"
            "`логин пароль`\n\n"
            "Например: `mylogin mypassword`",
            parse_mode='Markdown',
            reply_markup=reply_markup
        )
        
        # Устанавливаем состояние ожидания ввода данных аккаунта
        context = query.bot.context
        context.user_data[query.from_user.id] = {"state": "waiting_account_data"}
    
    async def handle_list_accounts_callback(self, query):
        """Обработчик callback для списка аккаунтов"""
        if not self.accounts:
            keyboard = [[InlineKeyboardButton("🔙 Назад", callback_data="back_to_accounts")]]
            reply_markup = InlineKeyboardMarkup(keyboard)
            await query.edit_message_text("👤 *Список аккаунтов*\n\nНет добавленных аккаунтов.", parse_mode='Markdown', reply_markup=reply_markup)
            return
        
        accounts_text = "👤 *Список аккаунтов*\n\n"
        keyboard = []
        
        for account_name in self.accounts:
            accounts_text += f"- {account_name}\n"
            keyboard.append([InlineKeyboardButton(f"❌ Удалить {account_name}", callback_data=f"remove_account:{account_name}")])
        
        keyboard.append([InlineKeyboardButton("🔙 Назад", callback_data="back_to_accounts")])
        reply_markup = InlineKeyboardMarkup(keyboard)
        await query.edit_message_text(accounts_text, reply_markup=reply_markup, parse_mode='Markdown')
    
    async def handle_toggle_plugin_callback(self, query, plugin_name):
        """Обработчик callback для включения/выключения плагина"""
        if plugin_name in self.plugin_manager.get_active_plugins():
            self.plugin_manager.disable_plugin(plugin_name)
            status_text = f"❌ Плагин {plugin_name} отключен"
        else:
            success, error = self.plugin_manager.enable_plugin(plugin_name)
            if success:
                status_text = f"✅ Плагин {plugin_name} включен"
            else:
                status_text = f"❌ Ошибка при включении плагина {plugin_name}: {error}"
        
        # Обновляем список плагинов
        plugins = self.plugin_manager.get_all_plugins()
        keyboard = []
        
        for p_name in plugins:
            is_active = p_name in self.plugin_manager.get_active_plugins()
            status = "✅" if is_active else "❌"
            keyboard.append([InlineKeyboardButton(f"{status} {p_name}", callback_data=f"toggle_plugin:{p_name}")])
        
        keyboard.append([InlineKeyboardButton("🔙 Назад в главное меню", callback_data="back_to_main")])
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await query.edit_message_text(
            f"🔌 *Управление плагинами*\n\n{status_text}\n\nНажмите на плагин для включения/отключения:",
            parse_mode='Markdown',
            reply_markup=reply_markup
        )
    
    async def handle_toggle_auto_bump_callback(self, query):
        """Обработчик callback для включения/выключения автоподнятия"""
        config.AUTO_BUMP_ENABLED = not config.AUTO_BUMP_ENABLED
        config.save_config()
        
        # Обновляем меню настроек
        keyboard = [
            [InlineKeyboardButton(f"🔄 Автоподнятие: {'✅' if config.AUTO_BUMP_ENABLED else '❌'}", 
                                 callback_data="toggle_auto_bump")],
            [InlineKeyboardButton(f"⏱️ Интервал автоподнятия: {config.AUTO_BUMP_INTERVAL // 60} мин", 
                                 callback_data="set_bump_interval")],
            [InlineKeyboardButton(f"🔄 Автовосстановление: {'✅' if config.AUTO_RESTORE_ENABLED else '❌'}", 
                                 callback_data="toggle_auto_restore")],
            [InlineKeyboardButton(f"🔔 Уведомления: {'✅' if config.NOTIFICATIONS_ENABLED else '❌'}", 
                                 callback_data="toggle_notifications")],
            [InlineKeyboardButton(f"💬 Автоответ: {'✅' if config.AUTO_REPLY_ENABLED else '❌'}", 
                                 callback_data="toggle_auto_reply")],
            [InlineKeyboardButton("🔙 Назад в главное меню", callback_data="back_to_main")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        status = "включено" if config.AUTO_BUMP_ENABLED else "отключено"
        await query.edit_message_text(
            f"⚙️ *Настройки бота*\n\n✅ Автоподнятие {status}!\n\nНажмите на параметр для изменения:",
            parse_mode='Markdown',
            reply_markup=reply_markup
        )
    
    async def handle_toggle_auto_restore_callback(self, query):
        """Обработчик callback для включения/выключения автовосстановления"""
        config.AUTO_RESTORE_ENABLED = not config.AUTO_RESTORE_ENABLED
        config.save_config()
        
        # Обновляем меню настроек
        keyboard = [
            [InlineKeyboardButton(f"🔄 Автоподнятие: {'✅' if config.AUTO_BUMP_ENABLED else '❌'}", 
                                 callback_data="toggle_auto_bump")],
            [InlineKeyboardButton(f"⏱️ Интервал автоподнятия: {config.AUTO_BUMP_INTERVAL // 60} мин", 
                                 callback_data="set_bump_interval")],
            [InlineKeyboardButton(f"🔄 Автовосстановление: {'✅' if config.AUTO_RESTORE_ENABLED else '❌'}", 
                                 callback_data="toggle_auto_restore")],
            [InlineKeyboardButton(f"🔔 Уведомления: {'✅' if config.NOTIFICATIONS_ENABLED else '❌'}", 
                                 callback_data="toggle_notifications")],
            [InlineKeyboardButton(f"💬 Автоответ: {'✅' if config.AUTO_REPLY_ENABLED else '❌'}", 
                                 callback_data="toggle_auto_reply")],
            [InlineKeyboardButton("🔙 Назад в главное меню", callback_data="back_to_main")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        status = "включено" if config.AUTO_RESTORE_ENABLED else "отключено"
        await query.edit_message_text(
            f"⚙️ *Настройки бота*\n\n✅ Автовосстановление {status}!\n\nНажмите на параметр для изменения:",
            parse_mode='Markdown',
            reply_markup=reply_markup
        )
    
    async def handle_toggle_notifications_callback(self, query):
        """Обработчик callback для включения/выключения уведомлений"""
        config.NOTIFICATIONS_ENABLED = not config.NOTIFICATIONS_ENABLED
        config.save_config()
        
        # Обновляем меню настроек
        keyboard = [
            [InlineKeyboardButton(f"🔄 Автоподнятие: {'✅' if config.AUTO_BUMP_ENABLED else '❌'}", 
                                 callback_data="toggle_auto_bump")],
            [InlineKeyboardButton(f"⏱️ Интервал автоподнятия: {config.AUTO_BUMP_INTERVAL // 60} мин", 
                                 callback_data="set_bump_interval")],
            [InlineKeyboardButton(f"🔄 Автовосстановление: {'✅' if config.AUTO_RESTORE_ENABLED else '❌'}", 
                                 callback_data="toggle_auto_restore")],
            [InlineKeyboardButton(f"🔔 Уведомления: {'✅' if config.NOTIFICATIONS_ENABLED else '❌'}", 
                                 callback_data="toggle_notifications")],
            [InlineKeyboardButton(f"💬 Автоответ: {'✅' if config.AUTO_REPLY_ENABLED else '❌'}", 
                                 callback_data="toggle_auto_reply")],
            [InlineKeyboardButton("🔙 Назад в главное меню", callback_data="back_to_main")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        status = "включены" if config.NOTIFICATIONS_ENABLED else "отключены"
        await query.edit_message_text(
            f"⚙️ *Настройки бота*\n\n✅ Уведомления {status}!\n\nНажмите на параметр для изменения:",
            parse_mode='Markdown',
            reply_markup=reply_markup
        )
    
    async def handle_toggle_auto_reply_callback(self, query):
        """Обработчик callback для включения/выключения автоответа"""
        config.AUTO_REPLY_ENABLED = not config.AUTO_REPLY_ENABLED
        config.save_config()
        
        # Обновляем меню настроек
        keyboard = [
            [InlineKeyboardButton(f"🔄 Автоподнятие: {'✅' if config.AUTO_BUMP_ENABLED else '❌'}", 
                                 callback_data="toggle_auto_bump")],
            [InlineKeyboardButton(f"⏱️ Интервал автоподнятия: {config.AUTO_BUMP_INTERVAL // 60} мин", 
                                 callback_data="set_bump_interval")],
            [InlineKeyboardButton(f"🔄 Автовосстановление: {'✅' if config.AUTO_RESTORE_ENABLED else '❌'}", 
                                 callback_data="toggle_auto_restore")],
            [InlineKeyboardButton(f"🔔 Уведомления: {'✅' if config.NOTIFICATIONS_ENABLED else '❌'}", 
                                 callback_data="toggle_notifications")],
            [InlineKeyboardButton(f"💬 Автоответ: {'✅' if config.AUTO_REPLY_ENABLED else '❌'}", 
                                 callback_data="toggle_auto_reply")],
            [InlineKeyboardButton("🔙 Назад в главное меню", callback_data="back_to_main")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        status = "включен" if config.AUTO_REPLY_ENABLED else "отключен"
        await query.edit_message_text(
            f"⚙️ *Настройки бота*\n\n✅ Автоответ {status}!\n\nНажмите на параметр для изменения:",
            parse_mode='Markdown',
            reply_markup=reply_markup
        )
    
    async def handle_set_bump_interval_callback(self, query):
        """Обработчик callback для установки интервала автоподнятия"""
        keyboard = [
            [
                InlineKeyboardButton("30 мин", callback_data="set_interval:30"),
                InlineKeyboardButton("1 час", callback_data="set_interval:60"),
                InlineKeyboardButton("2 часа", callback_data="set_interval:120")
            ],
            [
                InlineKeyboardButton("3 часа", callback_data="set_interval:180"),
                InlineKeyboardButton("6 часов", callback_data="set_interval:360"),
                InlineKeyboardButton("12 часов", callback_data="set_interval:720")
            ],
            [InlineKeyboardButton("🔙 Назад", callback_data="back_to_settings")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await query.edit_message_text(
            "⏱️ *Установка интервала автоподнятия*\n\n"
            f"Текущий интервал: {config.AUTO_BUMP_INTERVAL // 60} мин\n\n"
            "Выберите новый интервал:",
            parse_mode='Markdown',
            reply_markup=reply_markup
        )
    
    async def handle_bump_items_callback(self, query):
        """Обработчик callback для поднятия товаров"""
        if not self.accounts:
            keyboard = [[InlineKeyboardButton("🔙 Назад", callback_data="back_to_items_management")]]
            reply_markup = InlineKeyboardMarkup(keyboard)
            await query.edit_message_text(
                "🔄 *Поднятие товаров*\n\n"
                "Нет добавленных аккаунтов.",
                parse_mode='Markdown',
                reply_markup=reply_markup
            )
            return
        
        await query.edit_message_text("🔄 *Начинаю поднятие товаров...*", parse_mode='Markdown')
        
        results = []
        for username, account_data in self.accounts.items():
            try:
                success, result = await self.playerok_api.bump_items(username, account_data["password"])
                if success:
                    results.append(f"✅ {username}: {result}")
                else:
                    results.append(f"❌ {username}: {result}")
            except Exception as e:
                results.append(f"❌ {username}: Ошибка - {str(e)}")
        
        keyboard = [[InlineKeyboardButton("🔙 Назад", callback_data="back_to_items_management")]]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await query.edit_message_text(
            "🔄 *Результаты поднятия товаров*\n\n" + "\n".join(results),
            parse_mode='Markdown',
            reply_markup=reply_markup
        )
    
    async def handle_restore_items_callback(self, query):
        """Обработчик callback для восстановления товаров"""
        if not self.accounts:
            keyboard = [[InlineKeyboardButton("🔙 Назад", callback_data="back_to_items_management")]]
            reply_markup = InlineKeyboardMarkup(keyboard)
            await query.edit_message_text(
                "🔄 *Восстановление товаров*\n\n"
                "Нет добавленных аккаунтов.",
                parse_mode='Markdown',
                reply_markup=reply_markup
            )
            return
        
        await query.edit_message_text("🔄 *Начинаю восстановление товаров...*", parse_mode='Markdown')
        
        results = []
        for username, account_data in self.accounts.items():
            try:
                success, result = await self.playerok_api.restore_items(username, account_data["password"])
                if success:
                    results.append(f"✅ {username}: {result}")
                else:
                    results.append(f"❌ {username}: {result}")
            except Exception as e:
                results.append(f"❌ {username}: Ошибка - {str(e)}")
        
        keyboard = [[InlineKeyboardButton("🔙 Назад", callback_data="back_to_items_management")]]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await query.edit_message_text(
            "🔄 *Результаты восстановления товаров*\n\n" + "\n".join(results),
            parse_mode='Markdown',
            reply_markup=reply_markup
        )
    
    async def handle_remove_account_callback(self, query, account_name):
        """Обработчик callback для удаления аккаунта"""
        if account_name in self.accounts:
            del self.accounts[account_name]
            self.save_accounts()
            
            # Обновляем список аккаунтов
            if not self.accounts:
                keyboard = [[InlineKeyboardButton("🔙 Назад", callback_data="back_to_accounts")]]
                reply_markup = InlineKeyboardMarkup(keyboard)
                await query.edit_message_text(
                    f"👤 *Список аккаунтов*\n\n✅ Аккаунт {account_name} удален!\n\nНет добавленных аккаунтов.",
                    parse_mode='Markdown',
                    reply_markup=reply_markup
                )
                return
            
            accounts_text = f"👤 *Список аккаунтов*\n\n✅ Аккаунт {account_name} удален!\n\n"
            keyboard = []
            
            for acc_name in self.accounts:
                accounts_text += f"- {acc_name}\n"
                keyboard.append([InlineKeyboardButton(f"❌ Удалить {acc_name}", callback_data=f"remove_account:{acc_name}")])
            
            keyboard.append([InlineKeyboardButton("🔙 Назад", callback_data="back_to_accounts")])
            reply_markup = InlineKeyboardMarkup(keyboard)
            await query.edit_message_text(accounts_text, reply_markup=reply_markup, parse_mode='Markdown')
        else:
            keyboard = [[InlineKeyboardButton("🔙 Назад", callback_data="back_to_accounts")]]
            reply_markup = InlineKeyboardMarkup(keyboard)
            await query.edit_message_text(
                f"👤 *Список аккаунтов*\n\n❌ Аккаунт {account_name} не найден!",
                parse_mode='Markdown',
                reply_markup=reply_markup
            )
    
    async def message_handler(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Обработчик всех сообщений"""
        # Проверка на сообщения из меню
        if update.effective_chat.type == "private":
            message_text = update.message.text
            
            # Обработка сообщений из главного меню
            if message_text == "👤 Аккаунты":
                await self.handle_accounts_menu(update, context)
            elif message_text == "🔌 Плагины":
                await self.handle_plugins_menu(update, context)
            elif message_text == "⚙️ Настройки":
                await self.handle_settings_menu(update, context)
            elif message_text == "📊 Статистика":
                await self.handle_stats_menu(update, context)
            elif message_text == "🔄 Управление товарами":
                await self.handle_items_management_menu(update, context)
            elif message_text == "❓ Помощь":
                await self.help_command(update, context)
            # Обработка ввода данных аккаунта
            elif "state" in context.user_data.get(update.effective_user.id, {}) and context.user_data[update.effective_user.id]["state"] == "waiting_account_data":
                await self.handle_account_data_input(update, context)
            # Обработка ввода интервала автоподнятия
            elif "state" in context.user_data.get(update.effective_user.id, {}) and context.user_data[update.effective_user.id]["state"] == "waiting_interval":
                await self.handle_interval_input(update, context)
            # Проверка на сообщения от Playerok
            elif config.AUTO_REPLY_ENABLED:
                # Передаем обработку плагинам
                for plugin in self.plugin_manager.get_active_plugins().values():
                    if hasattr(plugin, 'handle_message') and await plugin.handle_message(update, context):
                        return
                
                # Обработка сообщений от Playerok
                if "заказ был выполнен" in message_text.lower():
                    await update.message.reply_text("Спасибо за заказ! Буду рад видеть вас снова! ❤️")
                elif "проблема с заказом" in message_text.lower():
                    await update.message.reply_text("Извините за неудобства. Пожалуйста, опишите проблему подробнее, и я постараюсь помочь.")
    
    async def handle_account_data_input(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Обработчик ввода данных аккаунта"""
        user_id = update.effective_user.id
        if user_id not in config.ADMIN_IDS:
            await update.message.reply_text("У вас нет доступа к этой функции.")
            return
        
        # Сбрасываем состояние
        context.user_data[user_id]["state"] = None
        
        message_text = update.message.text
        parts = message_text.split()
        
        if len(parts) < 2:
            await update.message.reply_text(
                "❌ *Неверный формат данных*\n\n"
                "Необходимо указать логин и пароль через пробел.\n"
                "Например: `mylogin mypassword`",
                parse_mode='Markdown'
            )
            return
        
        username = parts[0]
        password = parts[1]
        
        # Проверка подключения к аккаунту
        message = await update.message.reply_text("🔄 *Проверка подключения к аккаунту...*", parse_mode='Markdown')
        
        success, result = await self.playerok_api.login(username, password)
        
        if success:
            # Сохранение аккаунта
            self.accounts[username] = {
                "password": password,
                "active_items": 0,
                "completed_orders": 0,
                "returned_orders": 0,
                "income": 0
            }
            self.save_accounts()
            
            await message.edit_text(f"✅ *Аккаунт {username} успешно добавлен!*", parse_mode='Markdown')
        else:
            await message.edit_text(f"❌ *Ошибка при добавлении аккаунта:* {result}", parse_mode='Markdown')
    
    async def handle_interval_input(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Обработчик ввода интервала автоподнятия"""
        user_id = update.effective_user.id
        if user_id not in config.ADMIN_IDS:
            await update.message.reply_text("У вас нет доступа к этой функции.")
            return
        
        # Сбрасываем состояние
        context.user_data[user_id]["state"] = None
        
        message_text = update.message.text
        
        if not message_text.isdigit():
            await update.message.reply_text(
                "❌ *Неверный формат интервала*\n\n"
                "Интервал должен быть числом (в минутах).",
                parse_mode='Markdown'
            )
            return
        
        interval_minutes = int(message_text)
        if interval_minutes < 5:
            await update.message.reply_text(
                "❌ *Слишком маленький интервал*\n\n"
                "Минимальный интервал - 5 минут.",
                parse_mode='Markdown'
            )
            return
        
        config.AUTO_BUMP_INTERVAL = interval_minutes * 60
        config.save_config()
        await update.message.reply_text(f"✅ *Интервал автоподнятия установлен на {interval_minutes} минут.*", parse_mode='Markdown')
    
    async def auto_bump_task(self):
        """Задача для автоматического поднятия товаров"""
        while True:
            if config.AUTO_BUMP_ENABLED and self.accounts:
                logger.info("Запуск автоматического поднятия товаров")
                
                for username, account_data in self.accounts.items():
                    try:
                        success, result = await self.playerok_api.bump_items(username, account_data["password"])
                        if success:
                            logger.info(f"Автоподнятие для {username}: {result}")
                            if config.NOTIFICATIONS_ENABLED:
                                for admin_id in config.ADMIN_IDS:
                                    try:
                                        await self.application.bot.send_message(
                                            chat_id=admin_id,
                                            text=f"🔄 Автоподнятие для {username}: {result}"
                                        )
                                    except Exception as e:
                                        logger.error(f"Ошибка отправки уведомления: {e}")
                        else:
                            logger.error(f"Ошибка автоподнятия для {username}: {result}")
                            if config.NOTIFICATIONS_ENABLED:
                                for admin_id in config.ADMIN_IDS:
                                    try:
                                        await self.application.bot.send_message(
                                            chat_id=admin_id,
                                            text=f"❌ Ошибка автоподнятия для {username}: {result}"
                                        )
                                    except Exception as e:
                                        logger.error(f"Ошибка отправки уведомления: {e}")
                    except Exception as e:
                        logger.error(f"Исключение при автоподнятии для {username}: {e}")
            
            # Ждем до следующего запуска
            await asyncio.sleep(config.AUTO_BUMP_INTERVAL)
    
    async def auto_restore_task(self):
        """Задача для автоматического восстановления товаров"""
        while True:
            if config.AUTO_RESTORE_ENABLED and self.accounts:
                logger.info("Запуск автоматического восстановления товаров")
                
                for username, account_data in self.accounts.items():
                    try:
                        success, result = await self.playerok_api.restore_items(username, account_data["password"])
                        if success:
                            logger.info(f"Автовосстановление для {username}: {result}")
                            if config.NOTIFICATIONS_ENABLED:
                                for admin_id in config.ADMIN_IDS:
                                    try:
                                        await self.application.bot.send_message(
                                            chat_id=admin_id,
                                            text=f"🔄 Автовосстановление для {username}: {result}"
                                        )
                                    except Exception as e:
                                        logger.error(f"Ошибка отправки уведомления: {e}")
                        else:
                            logger.error(f"Ошибка автовосстановления для {username}: {result}")
                            if config.NOTIFICATIONS_ENABLED:
                                for admin_id in config.ADMIN_IDS:
                                    try:
                                        await self.application.bot.send_message(
                                            chat_id=admin_id,
                                            text=f"❌ Ошибка автовосстановления для {username}: {result}"
                                        )
                                    except Exception as e:
                                        logger.error(f"Ошибка отправки уведомления: {e}")
                    except Exception as e:
                        logger.error(f"Исключение при автовосстановлении для {username}: {e}")
            
            # Ждем до следующего запуска
            await asyncio.sleep(config.AUTO_RESTORE_INTERVAL)
    
    def load_accounts(self):
        """Загрузка аккаунтов из файла"""
        accounts_file = os.path.join(config.DATA_DIR, "accounts.json")
        if os.path.exists(accounts_file):
            try:
                with open(accounts_file, "r", encoding="utf-8") as f:
                    self.accounts = json.load(f)
                logger.info(f"Загружено {len(self.accounts)} аккаунтов")
            except Exception as e:
                logger.error(f"Ошибка загрузки аккаунтов: {e}")
                self.accounts = {}
    
    def save_accounts(self):
        """Сохранение аккаунтов в файл"""
        accounts_file = os.path.join(config.DATA_DIR, "accounts.json")
        try:
            with open(accounts_file, "w", encoding="utf-8") as f:
                json.dump(self.accounts, f, indent=4, ensure_ascii=False)
            logger.info(f"Сохранено {len(self.accounts)} аккаунтов")
        except Exception as e:
            logger.error(f"Ошибка сохранения аккаунтов: {e}")
    
    async def run(self):
        """Запуск бота"""
        # Создание и настройка приложения
        self.application = Application.builder().token(config.BOT_TOKEN).build()
        
        # Регистрация обработчиков команд
        self.application.add_handler(CommandHandler("start", self.start_command))
        self.application.add_handler(CommandHandler("help", self.help_command))
        self.application.add_handler(CommandHandler("status", self.status_command))
        
        # Регистрация обработчика callback-запросов
        self.application.add_handler(CallbackQueryHandler(self.callback_handler))
        
        # Регистрация обработчика сообщений
        self.application.add_handler(MessageHandler(filters.TEXT, self.message_handler))
        
        # Загрузка плагинов
        self.plugin_manager.load_plugins()
        
        # Запуск фоновых задач
        asyncio.create_task(self.auto_bump_task())
        asyncio.create_task(self.auto_restore_task())
        
        # Запуск бота
        await self.application.initialize()
        await self.application.start()
        await self.application.updater.start_polling()
        
        logger.info("Бот запущен")
        
        # Ожидание завершения работы бота
        await self.application.updater.stop()
        await self.application.stop()
        await self.application.shutdown()

if __name__ == "__main__":
    try:
        # Создание и запуск бота
        bot = PlayerokBot()
        asyncio.run(bot.run())
    except Exception as e:
        logger.error(f"Критическая ошибка: {e}")
        logger.error(traceback.format_exc())
